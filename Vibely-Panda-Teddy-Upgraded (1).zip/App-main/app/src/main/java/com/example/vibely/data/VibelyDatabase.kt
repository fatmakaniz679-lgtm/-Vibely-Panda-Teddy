package com.example.vibely.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities =
    [
      RoomStateEntity::class,
      RoomFurnitureEntity::class,
      MemoryEntity::class,
      TimeCapsuleEntity::class,
      ChatMessageEntity::class,
      ReelEntity::class,
      ReelCommentEntity::class,
      BoardEntity::class,
      ExplorePinEntity::class,
      PlaylistTrackEntity::class,
      CinemaTitleEntity::class,
      TwoMindsEntity::class,
      UserProfileEntity::class,
    ],
  version = 1,
  exportSchema = false,
)
abstract class VibelyDatabase : RoomDatabase() {
  abstract fun vibelyDao(): VibelyDao

  companion object {
    @Volatile private var instance: VibelyDatabase? = null

    fun getInstance(context: Context): VibelyDatabase =
      instance
        ?: synchronized(this) {
          instance
            ?: Room.databaseBuilder(
                context.applicationContext,
                VibelyDatabase::class.java,
                "vibely_universe.db",
              )
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
              .also { instance = it }
        }
  }
}
