package com.example.vibely.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VibelyDao {
  // Room state
  @Query("SELECT * FROM room_state WHERE id = 1")
  fun observeRoomState(): Flow<RoomStateEntity?>

  @Query("SELECT COUNT(*) FROM room_state")
  suspend fun countRoomStates(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertRoomState(state: RoomStateEntity)

  // Furniture
  @Query("SELECT * FROM room_furniture ORDER BY id ASC")
  fun observeFurniture(): Flow<List<RoomFurnitureEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertFurnitureAll(items: List<RoomFurnitureEntity>)

  @Update
  suspend fun updateFurniture(item: RoomFurnitureEntity)

  // Memories
  @Query("SELECT * FROM memories ORDER BY timestamp DESC")
  fun observeMemories(): Flow<List<MemoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMemory(memory: MemoryEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMemories(memories: List<MemoryEntity>)

  @Query("DELETE FROM memories WHERE id = :id")
  suspend fun deleteMemory(id: Int)

  // Time capsules
  @Query("SELECT * FROM time_capsules ORDER BY createdAt DESC")
  fun observeCapsules(): Flow<List<TimeCapsuleEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCapsule(capsule: TimeCapsuleEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCapsules(capsules: List<TimeCapsuleEntity>)

  @Update
  suspend fun updateCapsule(capsule: TimeCapsuleEntity)

  // Chat messages
  @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
  fun observeChatMessages(): Flow<List<ChatMessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: ChatMessageEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessages(messages: List<ChatMessageEntity>)

  @Update
  suspend fun updateMessage(message: ChatMessageEntity)

  @Query("DELETE FROM chat_messages WHERE id = :id")
  suspend fun deleteMessage(id: Int)

  // Reels & comments
  @Query("SELECT * FROM reels ORDER BY createdAt DESC")
  fun observeReels(): Flow<List<ReelEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReel(reel: ReelEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReels(reels: List<ReelEntity>)

  @Update
  suspend fun updateReel(reel: ReelEntity)

  @Query("SELECT * FROM reel_comments ORDER BY timestamp ASC")
  fun observeReelComments(): Flow<List<ReelCommentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReelComment(comment: ReelCommentEntity)

  // Boards & Explore pins
  @Query("SELECT * FROM boards ORDER BY id ASC")
  fun observeBoards(): Flow<List<BoardEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBoard(board: BoardEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBoards(boards: List<BoardEntity>)

  @Query("SELECT * FROM explore_pins ORDER BY id ASC")
  fun observeExplorePins(): Flow<List<ExplorePinEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertExplorePins(pins: List<ExplorePinEntity>)

  @Update
  suspend fun updateExplorePin(pin: ExplorePinEntity)

  // Music playlist
  @Query("SELECT * FROM playlist_tracks ORDER BY id ASC")
  fun observeTracks(): Flow<List<PlaylistTrackEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTrack(track: PlaylistTrackEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTracks(tracks: List<PlaylistTrackEntity>)

  @Update
  suspend fun updateTrack(track: PlaylistTrackEntity)

  // Cinema
  @Query("SELECT * FROM cinema_titles ORDER BY id ASC")
  fun observeCinemaTitles(): Flow<List<CinemaTitleEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCinemaTitles(titles: List<CinemaTitleEntity>)

  @Update
  suspend fun updateCinemaTitle(title: CinemaTitleEntity)

  // Two Minds
  @Query("SELECT * FROM two_minds ORDER BY id ASC")
  fun observeTwoMinds(): Flow<List<TwoMindsEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTwoMinds(items: List<TwoMindsEntity>)

  @Update
  suspend fun updateTwoMind(item: TwoMindsEntity)

  // Profiles (strictly two accounts: A & B)
  @Query("SELECT * FROM user_profiles ORDER BY slot ASC")
  fun observeProfiles(): Flow<List<UserProfileEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertProfiles(profiles: List<UserProfileEntity>)

  @Update
  suspend fun updateProfile(profile: UserProfileEntity)
}
