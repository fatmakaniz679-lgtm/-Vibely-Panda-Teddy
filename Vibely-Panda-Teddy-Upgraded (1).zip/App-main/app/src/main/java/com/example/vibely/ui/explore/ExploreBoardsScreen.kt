package com.example.vibely.ui.explore

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CinemaCard
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyLavender
import com.example.ui.theme.VibelyLavenderSoft
import com.example.ui.theme.VibelyPeach
import com.example.ui.theme.VibelyPeachSoft
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.vibely.data.BoardEntity
import com.example.vibely.data.ExplorePinEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreBoardsScreen(
  pins: List<ExplorePinEntity>,
  boards: List<BoardEntity>,
  onSavePinToBoard: (ExplorePinEntity, Int?) -> Unit,
  onCreateBoard: (String, String) -> Unit,
  bottomContentPadding: PaddingValues,
) {
  var activeTab by remember { mutableStateOf("Discover") }
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("All") }
  var selectedColor by remember { mutableStateOf("All") }
  var pinToSave by remember { mutableStateOf<ExplorePinEntity?>(null) }
  var showNewBoardDialog by remember { mutableStateOf(false) }

  val categories = listOf("All", "Room Designs", "Aesthetic", "Wallpapers", "Music", "Movies", "Fashion", "Travel", "Art")
  val colorSwatches =
    listOf(
      "All" to Color.White,
      "Pink" to VibelyPinkSoft,
      "Peach" to VibelyPeachSoft,
      "Lavender" to VibelyLavenderSoft,
      "Cream" to Color(0xFFF6EAD9),
      "Midnight" to CinemaCard,
    )

  val filteredPins =
    remember(pins, searchQuery, selectedCategory, selectedColor) {
      pins.filter { pin ->
        val matchesQuery =
          searchQuery.isBlank() ||
            pin.title.contains(searchQuery, ignoreCase = true) ||
            pin.category.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == "All" || pin.category == selectedCategory
        val matchesColor = selectedColor == "All" || pin.colorTag == selectedColor
        matchesQuery && matchesCategory && matchesColor
      }
    }

  Column(
    modifier = Modifier.fillMaxSize().background(VibelyCream).statusBarsPadding(),
  ) {
    // Top Header + Mode Switcher
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text("Explore", style = MaterialTheme.typography.headlineMedium, color = VibelyInk)
        Text("Curated inspiration & Vibely Boards", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Discover", "Boards").forEach { tab ->
          val selected = activeTab == tab
          Surface(
            onClick = { activeTab = tab },
            shape = CircleShape,
            color = if (selected) VibelyPink else Color.White,
            border = BorderStroke(1.dp, if (selected) VibelyPink else MaterialTheme.colorScheme.outline),
            modifier = Modifier.testTag("explore_tab_$tab"),
          ) {
            Text(
              text = tab,
              style = MaterialTheme.typography.labelLarge,
              color = if (selected) Color.White else VibelyInk,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            )
          }
        }
      }
    }

    if (activeTab == "Discover") {
      // Search Bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search room designs, wallpapers, aesthetic...") },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = VibelyPink) },
        singleLine = true,
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).testTag("explore_search_input"),
      )

      Spacer(Modifier.height(10.dp))

      // Color-Based Discovery Swatches
      LazyRow(
        contentPadding = PaddingValues(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        items(colorSwatches) { (name, swatchColor) ->
          val selected = selectedColor == name
          Surface(
            onClick = { selectedColor = name },
            shape = CircleShape,
            color = Color.White,
            border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) VibelyPink else MaterialTheme.colorScheme.outline),
            modifier = Modifier.testTag("color_filter_$name"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              if (name != "All") {
                Box(
                  modifier =
                    Modifier
                      .size(14.dp)
                      .background(swatchColor, CircleShape)
                      .border(1.dp, Color.Black.copy(alpha = 0.12f), CircleShape)
                )
              }
              Text(name, style = MaterialTheme.typography.labelMedium, color = VibelyInk)
            }
          }
        }
      }

      Spacer(Modifier.height(8.dp))

      // Category Chips
      LazyRow(
        contentPadding = PaddingValues(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(categories) { category ->
          FilterChip(
            selected = selectedCategory == category,
            onClick = { selectedCategory = category },
            label = { Text(category) },
            modifier = Modifier.testTag("category_chip_$category"),
          )
        }
      }

      Spacer(Modifier.height(8.dp))

      // Pinterest-style 2-Column Staggered Masonry Grid
      LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(2),
        contentPadding =
          PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 4.dp,
            bottom = bottomContentPadding.calculateBottomPadding() + 24.dp,
          ),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalItemSpacing = 12.dp,
        modifier = Modifier.fillMaxSize().testTag("explore_masonry_grid"),
      ) {
        items(filteredPins, key = { it.id }) { pin ->
          val boardName = boards.firstOrNull { it.id == pin.savedBoardId }?.name
          ExplorePinCard(
            pin = pin,
            savedBoardName = boardName,
            onSaveClick = { pinToSave = pin },
          )
        }
      }
    } else {
      // Vibely Boards Collection View
      LazyColumn(
        contentPadding =
          PaddingValues(
            start = 18.dp,
            end = 18.dp,
            top = 6.dp,
            bottom = bottomContentPadding.calculateBottomPadding() + 24.dp,
          ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
      ) {
        item {
          Button(
            onClick = { showNewBoardDialog = true },
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("create_board_button"),
          ) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Create Vibely Board")
          }
        }

        items(boards, key = { it.id }) { board ->
          val count = pins.count { it.savedBoardId == board.id }
          Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color.White,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth().testTag("board_card_${board.id}"),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
              Box(
                modifier =
                  Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(board.accentHex)),
                contentAlignment = Alignment.Center,
              ) {
                Icon(Icons.Rounded.Bookmark, contentDescription = null, tint = VibelyInk)
              }
              Column(modifier = Modifier.weight(1f)) {
                Text(board.name, style = MaterialTheme.typography.titleMedium, color = VibelyInk)
                Text(board.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Surface(shape = CircleShape, color = Color(board.accentHex)) {
                Text(
                  text = "$count saved",
                  style = MaterialTheme.typography.labelMedium,
                  color = VibelyInk,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                )
              }
            }
          }
        }
      }
    }
  }

  // Save Pin to Vibely Board Sheet
  pinToSave?.let { pin ->
    ModalBottomSheet(
      onDismissRequest = { pinToSave = null },
      containerColor = VibelyCream,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text("Save '${pin.title}' to Board", style = MaterialTheme.typography.titleLarge, color = VibelyInk)
        boards.forEach { board ->
          val isCurrent = pin.savedBoardId == board.id
          Surface(
            onClick = {
              onSavePinToBoard(pin, if (isCurrent) null else board.id)
              pinToSave = null
            },
            shape = RoundedCornerShape(16.dp),
            color = if (isCurrent) Color(board.accentHex) else Color.White,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(board.name, style = MaterialTheme.typography.titleMedium, color = VibelyInk)
              Text(if (isCurrent) "Saved ✓" else "Save", style = MaterialTheme.typography.labelLarge, color = VibelyPink)
            }
          }
        }
        Spacer(Modifier.height(20.dp))
      }
    }
  }

  // Create New Board Dialog
  if (showNewBoardDialog) {
    var boardName by remember { mutableStateOf("") }
    var boardSub by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showNewBoardDialog = false },
      title = { Text("New Vibely Board") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = boardName,
            onValueChange = { boardName = it },
            label = { Text("Board Name") },
            singleLine = true,
          )
          OutlinedTextField(
            value = boardSub,
            onValueChange = { boardSub = it },
            label = { Text("Short Vibe / Description") },
            singleLine = true,
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (boardName.isNotBlank()) {
              onCreateBoard(boardName, boardSub)
              showNewBoardDialog = false
            }
          }
        ) {
          Text("Create")
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewBoardDialog = false }) { Text("Cancel") }
      },
    )
  }
}

@Composable
private fun ExplorePinCard(
  pin: ExplorePinEntity,
  savedBoardName: String?,
  onSaveClick: () -> Unit,
) {
  val cardHeight = (155 * pin.heightRatio).dp
  Surface(
    shape = RoundedCornerShape(22.dp),
    color = Color.White,
    shadowElevation = 3.dp,
    modifier = Modifier.fillMaxWidth().clickable(onClick = onSaveClick).testTag("explore_pin_${pin.id}"),
  ) {
    Column {
      Box(modifier = Modifier.fillMaxWidth().height(cardHeight)) {
        when (pin.artVariant) {
          0 ->
            Image(
              painter = painterResource(R.drawable.img_explore_aesthetic_1795279160167),
              contentDescription = pin.title,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          1 ->
            Image(
              painter = painterResource(R.drawable.img_virtual_room_bg_1795279159875),
              contentDescription = pin.title,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          2 ->
            Image(
              painter = painterResource(R.drawable.img_music_cover_1795279158690),
              contentDescription = pin.title,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          3 ->
            Image(
              painter = painterResource(R.drawable.img_cinema_featured_1795279160527),
              contentDescription = pin.title,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          else -> {
            val colors =
              when (pin.artVariant % 3) {
                0 -> listOf(VibelyPinkSoft, VibelyPeachSoft)
                1 -> listOf(VibelyLavenderSoft, VibelyPinkSoft)
                else -> listOf(VibelyPeachSoft, Color(0xFFFFF5EB))
              }
            Box(
              modifier =
                Modifier
                  .fillMaxSize()
                  .background(Brush.linearGradient(colors))
                  .padding(16.dp),
              contentAlignment = Alignment.BottomStart,
            ) {
              Text(
                text = pin.category,
                style = MaterialTheme.typography.headlineSmall,
                color = VibelyInk.copy(alpha = 0.6f),
              )
            }
          }
        }

        Surface(
          onClick = onSaveClick,
          shape = CircleShape,
          color = Color.White.copy(alpha = 0.90f),
          modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).size(36.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (savedBoardName != null) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
              contentDescription = "Save to board",
              tint = if (savedBoardName != null) VibelyPink else VibelyInk,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }

      Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(pin.title, style = MaterialTheme.typography.titleMedium, color = VibelyInk, fontWeight = FontWeight.Bold)
        Text(
          text = savedBoardName?.let { "Saved in $it" } ?: "${pin.category} • ${pin.colorTag}",
          style = MaterialTheme.typography.labelSmall,
          color = if (savedBoardName != null) VibelyPink else MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}
