package com.example.vibely.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "room_state")
data class RoomStateEntity(
  @PrimaryKey val id: Int = 1,
  val roomName: String = "Mochi & Boba's Loft",
  val wallpaperTheme: String = "Blush Cream",
  val lightingMode: String = "Warm Glow",
  val pandaMood: String = "Cozy",
  val teddyMood: String = "Happy",
  val activeUserSlot: String = "A", // Strictly "A" or "B"
  val showOnlineStatus: Boolean = true,
  val inviteCode: String = "VBLY-2026-DUO",
)

@Entity(tableName = "room_furniture")
data class RoomFurnitureEntity(
  @PrimaryKey val id: String,
  val name: String,
  val category: String,
  val iconKey: String,
  val xFraction: Float,
  val yFraction: Float,
  val isPlaced: Boolean = true,
  val customPhotoUri: String? = null,
  val accentColorHex: Long = 0xFFFCDCE6,
)

@Entity(tableName = "memories")
data class MemoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val title: String,
  val note: String,
  val dateLabel: String,
  val moodTag: String,
  val authorSlot: String,
  val photoUri: String? = null,
  val timestamp: Long = System.currentTimeMillis(),
)

@Entity(tableName = "time_capsules")
data class TimeCapsuleEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val title: String,
  val secretMessage: String,
  val unlockDateLabel: String,
  val isUnlocked: Boolean = false,
  val authorSlot: String,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val senderSlot: String,
  val text: String,
  val attachmentType: String? = null, // "sticker", "music", "movie", "reel"
  val attachmentLabel: String? = null,
  val reactionEmoji: String? = null,
  val replyPreview: String? = null,
  val timestamp: Long = System.currentTimeMillis(),
)

@Entity(tableName = "reels")
data class ReelEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val authorSlot: String,
  val caption: String,
  val audioTitle: String,
  val hashtags: String,
  val filterTag: String,
  val likedByA: Boolean = false,
  val likedByB: Boolean = false,
  val isSaved: Boolean = false,
  val isDraft: Boolean = false,
  val feedCategory: String = "For You",
  val mediaUri: String? = null,
  val coverStyle: Int = 0,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "reel_comments")
data class ReelCommentEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val reelId: Int,
  val authorSlot: String,
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
)

@Entity(tableName = "boards")
data class BoardEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val name: String,
  val subtitle: String,
  val accentHex: Long,
)

@Entity(tableName = "explore_pins")
data class ExplorePinEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val title: String,
  val category: String,
  val colorTag: String,
  val heightRatio: Float,
  val savedBoardId: Int? = null,
  val artVariant: Int = 0,
)

@Entity(tableName = "playlist_tracks")
data class PlaylistTrackEntity(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val title: String,
  val artist: String,
  val album: String,
  val durationSec: Int,
  val addedBySlot: String,
  val isFavorite: Boolean = false,
  val tintHex: Long = 0xFFEBE4FA,
)

@Entity(tableName = "cinema_titles")
data class CinemaTitleEntity(
  @PrimaryKey val id: String,
  val title: String,
  val category: String, // "Featured", "Movies", "Series"
  val genre: String,
  val year: Int,
  val duration: String,
  val synopsis: String,
  val languages: String,
  val subtitles: String,
  val sourceLabel: String, // Clearly distinguishes discovery vs authorized/public-domain source
  val inWatchlist: Boolean = false,
  val progressFraction: Float = 0f,
  val posterTone: Int = 0,
)

@Entity(tableName = "two_minds")
data class TwoMindsEntity(
  @PrimaryKey val id: Int,
  val prompt: String,
  val answerA: String? = null,
  val answerB: String? = null,
)

@Entity(tableName = "user_profiles")
data class UserProfileEntity(
  @PrimaryKey val slot: String, // "A" or "B"
  val displayName: String,
  val handle: String,
  val bio: String,
  val avatarBadge: String,
  val favoriteSong: String,
  val personalTheme: String,
  val diaryNote: String,
  val avatarTintHex: Long,
)
