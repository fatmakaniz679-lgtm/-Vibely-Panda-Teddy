package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val VibelyLightColorScheme =
  lightColorScheme(
    primary = VibelyPink,
    onPrimary = VibelyOnPink,
    primaryContainer = VibelyPinkSoft,
    onPrimaryContainer = VibelyOnPinkSoft,
    secondary = VibelyPeach,
    onSecondary = VibelyOnPink,
    secondaryContainer = VibelyPeachSoft,
    onSecondaryContainer = VibelyOnPeachSoft,
    tertiary = VibelyLavender,
    onTertiary = VibelyOnPink,
    tertiaryContainer = VibelyLavenderSoft,
    onTertiaryContainer = VibelyOnLavenderSoft,
    background = VibelyCream,
    onBackground = VibelyInk,
    surface = VibelySurfaceWhite,
    onSurface = VibelyInk,
    surfaceVariant = VibelyCreamVariant,
    onSurfaceVariant = VibelyMuted,
    outline = VibelyOutline,
  )

private val VibelyDarkColorScheme =
  darkColorScheme(
    primary = CinemaAccentPink,
    onPrimary = CinemaBg,
    primaryContainer = Color(0xFF4C2436),
    onPrimaryContainer = VibelyPinkSoft,
    secondary = CinemaAccentPeach,
    onSecondary = CinemaBg,
    secondaryContainer = Color(0xFF4A2B1D),
    onSecondaryContainer = VibelyPeachSoft,
    tertiary = CinemaAccentLavender,
    onTertiary = CinemaBg,
    tertiaryContainer = Color(0xFF332952),
    onTertiaryContainer = VibelyLavenderSoft,
    background = CinemaBg,
    onBackground = CinemaText,
    surface = CinemaSurface,
    onSurface = CinemaText,
    surfaceVariant = CinemaCard,
    onSurfaceVariant = CinemaMuted,
    outline = Color(0xFF3B3552),
  )

val VibelyShapes =
  Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(34.dp),
  )

@Composable
fun VibelyTheme(
  darkTheme: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = if (darkTheme) VibelyDarkColorScheme else VibelyLightColorScheme,
    typography = VibelyTypography,
    shapes = VibelyShapes,
    content = content,
  )
}
