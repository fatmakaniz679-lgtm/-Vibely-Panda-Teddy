package com.example.vibely.ui.extras

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyGold
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyLavenderSoft
import com.example.ui.theme.VibelyMint
import com.example.ui.theme.VibelyMintSoft
import com.example.ui.theme.VibelyPeachSoft
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.vibely.data.MemoryEntity
import com.example.vibely.data.TimeCapsuleEntity
import com.example.vibely.data.TwoMindsEntity
import com.example.vibely.data.UserProfileEntity

@Composable
fun OurMemoriesScreen(
  memories: List<MemoryEntity>,
  profiles: List<UserProfileEntity>,
  onAddMemory: (title: String, note: String, mood: String, photoUri: String?) -> Unit,
  onDeleteMemory: (Int) -> Unit,
  onBack: () -> Unit,
) {
  var showAddDialog by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize().background(VibelyCream).statusBarsPadding().navigationBarsPadding()) {
    SubScreenHeader(
      title = "Our Memories",
      subtitle = "Shared timeline of photos & cozy notes",
      onBack = onBack,
      actionLabel = "Add",
      onAction = { showAddDialog = true },
    )

    LazyColumn(
      contentPadding = PaddingValues(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.fillMaxSize(),
    ) {
      items(memories, key = { it.id }) { mem ->
        val author = profiles.firstOrNull { it.slot == mem.authorSlot }?.displayName ?: mem.authorSlot
        Surface(
          shape = RoundedCornerShape(24.dp),
          color = Color.White,
          border = BorderStroke(1.dp, VibelyPinkSoft),
          shadowElevation = 2.dp,
          modifier = Modifier.fillMaxWidth().testTag("memory_card_${mem.id}"),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Surface(shape = CircleShape, color = VibelyPeachSoft) {
                Text("${mem.dateLabel} • ${mem.moodTag}", style = MaterialTheme.typography.labelSmall, color = VibelyInk, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
              }
              IconButton(onClick = { onDeleteMemory(mem.id) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete memory", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
              }
            }
            if (mem.photoUri != null) {
              AsyncImage(
                model = mem.photoUri,
                contentDescription = mem.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp)),
              )
            }
            Text(mem.title, style = MaterialTheme.typography.titleLarge, color = VibelyInk)
            Text(mem.note, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Saved by $author", style = MaterialTheme.typography.labelSmall, color = VibelyPink)
          }
        }
      }
    }
  }

  if (showAddDialog) {
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("Cozy") }
    var pickedPhotoUri by remember { mutableStateOf<String?>(null) }
    val picker =
      rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) pickedPhotoUri = uri.toString()
      }

    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text("New Shared Memory") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Memory Title") }, singleLine = true)
          OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Story / Note") }, minLines = 2)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf("Cozy", "Joyful", "Dreamy", "Milestone")) { tag ->
              FilterChip(selected = mood == tag, onClick = { mood = tag }, label = { Text(tag) })
            }
          }
          OutlinedButton(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Icon(Icons.Rounded.Photo, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(if (pickedPhotoUri != null) "Photo Attached ✓" else "Attach Photo")
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (title.isNotBlank()) {
              onAddMemory(title, note, mood, pickedPhotoUri)
              showAddDialog = false
            }
          }
        ) { Text("Save") }
      },
      dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } },
    )
  }
}

@Composable
fun TimeCapsuleScreen(
  capsules: List<TimeCapsuleEntity>,
  profiles: List<UserProfileEntity>,
  onCreateCapsule: (title: String, message: String, unlockDate: String) -> Unit,
  onUnlockCapsule: (TimeCapsuleEntity) -> Unit,
  onBack: () -> Unit,
) {
  var showCreateDialog by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize().background(VibelyCream).statusBarsPadding().navigationBarsPadding()) {
    SubScreenHeader(
      title = "Time Capsule",
      subtitle = "Seal secret messages for future dates",
      onBack = onBack,
      actionLabel = "Seal New",
      onAction = { showCreateDialog = true },
    )

    LazyColumn(
      contentPadding = PaddingValues(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      items(capsules, key = { it.id }) { cap ->
        val author = profiles.firstOrNull { it.slot == cap.authorSlot }?.displayName ?: cap.authorSlot
        Surface(
          shape = RoundedCornerShape(24.dp),
          color = if (cap.isUnlocked) Color.White else VibelyLavenderSoft,
          border = BorderStroke(1.dp, Color.White),
          shadowElevation = 3.dp,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                  if (cap.isUnlocked) Icons.Rounded.LockOpen else Icons.Rounded.Lock,
                  contentDescription = null,
                  tint = if (cap.isUnlocked) VibelyMint else VibelyPink,
                )
                Text(cap.title, style = MaterialTheme.typography.titleLarge, color = VibelyInk)
              }
              Icon(Icons.Rounded.HourglassBottom, contentDescription = null, tint = VibelyGold)
            }
            Text("Sealed by $author • Unlock: ${cap.unlockDateLabel}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (cap.isUnlocked) {
              Surface(shape = RoundedCornerShape(14.dp), color = VibelyPinkSoft.copy(alpha = 0.55f), modifier = Modifier.fillMaxWidth()) {
                Text(cap.secretMessage, style = MaterialTheme.typography.bodyLarge, color = VibelyInk, modifier = Modifier.padding(14.dp))
              }
            } else {
              OutlinedButton(
                onClick = { onUnlockCapsule(cap) },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
              ) {
                Text("Open Capsule Early (Preview)")
              }
            }
          }
        }
      }
    }
  }

  if (showCreateDialog) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var unlockDate by remember { mutableStateOf("Nov 21, 2027") }
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      title = { Text("Seal a Time Capsule") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Capsule Title") }, singleLine = true)
          OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Secret Future Note") }, minLines = 3)
          OutlinedTextField(value = unlockDate, onValueChange = { unlockDate = it }, label = { Text("Unlock Date") }, singleLine = true)
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (title.isNotBlank() && message.isNotBlank()) {
              onCreateCapsule(title, message, unlockDate)
              showCreateDialog = false
            }
          }
        ) { Text("Seal") }
      },
      dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") } },
    )
  }
}

@Composable
fun PlayTogetherScreen(
  twoMinds: List<TwoMindsEntity>,
  profiles: List<UserProfileEntity>,
  activeUserSlot: String,
  onSubmitTwoMinds: (TwoMindsEntity, String) -> Unit,
  onSwitchAccount: () -> Unit,
  onBack: () -> Unit,
) {
  var selectedGame by remember { mutableStateOf("Two Minds") }
  val games = listOf("Two Minds", "This or That", "Emoji Guess", "Duo Quiz")

  Column(modifier = Modifier.fillMaxSize().background(VibelyCream).statusBarsPadding().navigationBarsPadding()) {
    SubScreenHeader(
      title = "Play Together",
      subtitle = "Cozy two-player mini-games & daily reveals",
      onBack = onBack,
      actionLabel = "Switch (${activeUserSlot})",
      onAction = onSwitchAccount,
    )

    LazyRow(
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      items(games) { game ->
        FilterChip(selected = selectedGame == game, onClick = { selectedGame = game }, label = { Text(game) })
      }
    }

    LazyColumn(
      contentPadding = PaddingValues(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
      modifier = Modifier.fillMaxSize(),
    ) {
      when (selectedGame) {
        "Two Minds" -> {
          items(twoMinds, key = { it.id }) { item ->
            TwoMindsCard(
              item = item,
              profiles = profiles,
              activeSlot = activeUserSlot,
              onSubmit = { answer -> onSubmitTwoMinds(item, answer) },
            )
          }
        }
        "This or That" -> {
          item { ThisOrThatGameCard() }
        }
        "Emoji Guess" -> {
          item { EmojiGuessingGameCard() }
        }
        else -> {
          item { DuoQuizGameCard() }
        }
      }
    }
  }
}

@Composable
private fun TwoMindsCard(
  item: TwoMindsEntity,
  profiles: List<UserProfileEntity>,
  activeSlot: String,
  onSubmit: (String) -> Unit,
) {
  var draft by remember(item.id, activeSlot) { mutableStateOf("") }
  val bothAnswered = !item.answerA.isNullOrBlank() && !item.answerB.isNullOrBlank()
  val myAnswer = if (activeSlot == "A") item.answerA else item.answerB
  val nameA = profiles.firstOrNull { it.slot == "A" }?.displayName ?: "Aria"
  val nameB = profiles.firstOrNull { it.slot == "B" }?.displayName ?: "Zayn"

  Surface(
    shape = RoundedCornerShape(24.dp),
    color = Color.White,
    border = BorderStroke(1.dp, VibelyPinkSoft),
    shadowElevation = 2.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Text("DAILY TWO MINDS", style = MaterialTheme.typography.labelSmall, color = VibelyPink)
      Text(item.prompt, style = MaterialTheme.typography.titleLarge, color = VibelyInk)

      if (bothAnswered) {
        Surface(shape = RoundedCornerShape(14.dp), color = VibelyPinkSoft, modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(nameA, style = MaterialTheme.typography.labelMedium, color = VibelyPink)
            Text(item.answerA ?: "", style = MaterialTheme.typography.bodyLarge, color = VibelyInk)
          }
        }
        Surface(shape = RoundedCornerShape(14.dp), color = VibelyLavenderSoft, modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(nameB, style = MaterialTheme.typography.labelMedium, color = VibelyInk)
            Text(item.answerB ?: "", style = MaterialTheme.typography.bodyLarge, color = VibelyInk)
          }
        }
      } else if (!myAnswer.isNullOrBlank()) {
        Surface(shape = RoundedCornerShape(14.dp), color = VibelyMintSoft, modifier = Modifier.fillMaxWidth()) {
          Text(
            "Your answer is locked in! Waiting for your partner to answer so both reveal together.",
            style = MaterialTheme.typography.bodyMedium,
            color = VibelyInk,
            modifier = Modifier.padding(12.dp),
          )
        }
      } else {
        OutlinedTextField(
          value = draft,
          onValueChange = { draft = it },
          label = { Text("Your private answer (${if (activeSlot == "A") nameA else nameB})") },
          modifier = Modifier.fillMaxWidth(),
        )
        Button(
          onClick = {
            if (draft.isNotBlank()) {
              onSubmit(draft)
              draft = ""
            }
          },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        ) {
          Text("Lock In Answer")
        }
      }
    }
  }
}

@Composable
private fun ThisOrThatGameCard() {
  val pairs =
    listOf(
      "Rainy Rooftop Cinema" to "Sunny Picnic Blanket",
      "Iced Strawberry Matcha" to "Hot Caramel Cocoa",
      "Lo-Fi Vinyl Evening" to "Acoustic Midnight Drive",
      "Cozy Panda Plushie" to "Classic Teddy Bear",
    )
  var index by remember { mutableIntStateOf(0) }
  var picked by remember { mutableStateOf<String?>(null) }
  val (left, right) = pairs[index % pairs.size]

  Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text("THIS OR THAT • ROUND ${index + 1}/${pairs.size}", style = MaterialTheme.typography.labelMedium, color = VibelyPink)
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
          onClick = { picked = left },
          shape = RoundedCornerShape(20.dp),
          color = if (picked == left) VibelyPinkSoft else VibelyCream,
          border = BorderStroke(1.5.dp, if (picked == left) VibelyPink else MaterialTheme.colorScheme.outline),
          modifier = Modifier.weight(1f).height(110.dp),
        ) {
          Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(12.dp)) {
            Text(left, style = MaterialTheme.typography.titleMedium, color = VibelyInk)
          }
        }
        Surface(
          onClick = { picked = right },
          shape = RoundedCornerShape(20.dp),
          color = if (picked == right) VibelyLavenderSoft else VibelyCream,
          border = BorderStroke(1.5.dp, if (picked == right) VibelyPink else MaterialTheme.colorScheme.outline),
          modifier = Modifier.weight(1f).height(110.dp),
        ) {
          Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(12.dp)) {
            Text(right, style = MaterialTheme.typography.titleMedium, color = VibelyInk)
          }
        }
      }
      if (picked != null) {
        Text("You picked: $picked ✨", style = MaterialTheme.typography.labelLarge, color = VibelyPink)
      }
      Button(
        onClick = {
          index = (index + 1) % pairs.size
          picked = null
        },
        shape = CircleShape,
      ) { Text("Next Pair") }
    }
  }
}

@Composable
private fun EmojiGuessingGameCard() {
  val puzzles =
    listOf(
      Triple("🌙 ☁️ 🎵", "Peach Cloud Lullaby", listOf("Peach Cloud Lullaby", "Sunny Beach Pop", "Rock Anthem")),
      Triple("🎬 🗼 🕵️ 💌", "Charade (1963)", listOf("Space Odyssey", "Charade (1963)", "Jungle Run")),
      Triple("🐼 🛋️ 🪴 💡", "Our Virtual Loft", listOf("Beach Resort", "Our Virtual Loft", "Coffee Shop")),
    )
  var idx by remember { mutableIntStateOf(0) }
  var score by remember { mutableIntStateOf(0) }
  var result by remember { mutableStateOf<String?>(null) }
  val (clue, answer, options) = puzzles[idx % puzzles.size]

  Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text("EMOJI GUESSING • SCORE $score", style = MaterialTheme.typography.labelMedium, color = VibelyPink)
      Text(clue, style = MaterialTheme.typography.displaySmall)
      options.forEach { option ->
        OutlinedButton(
          onClick = {
            if (option == answer) {
              score += 1
              result = "Spot on! It's $answer 🎉"
            } else {
              result = "Close! Answer: $answer"
            }
          },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        ) {
          Text(option)
        }
      }
      result?.let { Text(it, style = MaterialTheme.typography.labelLarge, color = VibelyMint) }
      Button(
        onClick = {
          idx = (idx + 1) % puzzles.size
          result = null
        },
        shape = CircleShape,
      ) { Text("Next Clue") }
    }
  }
}

@Composable
private fun DuoQuizGameCard() {
  var answerSelected by remember { mutableStateOf<String?>(null) }
  Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Text("TWO-PLAYER COZY QUIZ", style = MaterialTheme.typography.labelMedium, color = VibelyPink)
      Text("What makes a perfect Sunday evening in our digital universe?", style = MaterialTheme.typography.titleLarge, color = VibelyInk)
      listOf(
        "Redecorating the loft & spinning Our Playlist",
        "Watch Together rooftop cinema with popcorn",
        "Opening a Time Capsule & writing memories",
      ).forEach { choice ->
        val selected = answerSelected == choice
        Surface(
          onClick = { answerSelected = choice },
          shape = RoundedCornerShape(16.dp),
          color = if (selected) VibelyPinkSoft else VibelyCream,
          border = BorderStroke(1.dp, if (selected) VibelyPink else MaterialTheme.colorScheme.outline),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(choice, style = MaterialTheme.typography.bodyLarge, color = VibelyInk, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(14.dp))
        }
      }
      if (answerSelected != null) {
        Text("Choice saved! Share it in Private Chat to compare.", style = MaterialTheme.typography.labelMedium, color = VibelyMint)
      }
    }
  }
}

@Composable
private fun SubScreenHeader(
  title: String,
  subtitle: String,
  onBack: () -> Unit,
  actionLabel: String,
  onAction: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = VibelyInk)
      }
      Column {
        Text(title, style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
    Surface(onClick = onAction, shape = CircleShape, color = VibelyPink) {
      Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(actionLabel, style = MaterialTheme.typography.labelMedium, color = Color.White)
      }
    }
  }
}
