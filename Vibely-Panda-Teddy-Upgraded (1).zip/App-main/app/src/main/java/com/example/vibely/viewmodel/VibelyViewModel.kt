package com.example.vibely.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vibely.data.BoardEntity
import com.example.vibely.data.ChatMessageEntity
import com.example.vibely.data.CinemaTitleEntity
import com.example.vibely.data.ExplorePinEntity
import com.example.vibely.data.MemoryEntity
import com.example.vibely.data.PlaylistTrackEntity
import com.example.vibely.data.ReelCommentEntity
import com.example.vibely.data.ReelEntity
import com.example.vibely.data.RoomFurnitureEntity
import com.example.vibely.data.RoomStateEntity
import com.example.vibely.data.TimeCapsuleEntity
import com.example.vibely.data.TwoMindsEntity
import com.example.vibely.data.UserProfileEntity
import com.example.vibely.data.VibelyDatabase
import com.example.vibely.data.VibelyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MusicPlayerState(
  val currentTrackIndex: Int = 0,
  val isPlaying: Boolean = false,
  val isShuffle: Boolean = false,
  val isRepeat: Boolean = false,
  val progressFraction: Float = 0.28f,
)

data class WatchTogetherState(
  val activeMovieId: String? = null,
  val isPlaying: Boolean = false,
  val positionFraction: Float = 0.25f,
  val partnerJoined: Boolean = true,
  val recentReactions: List<String> = listOf("🍿", "✨", "💛"),
  val roomChat: List<Pair<String, String>> =
    listOf("Zayn" to "Ready when you are!", "Aria" to "Popcorn is ready, hitting play!"),
)

class VibelyViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = VibelyRepository(VibelyDatabase.getInstance(application).vibelyDao())

  val roomState: StateFlow<RoomStateEntity> =
    repository.roomState
      .map { it ?: RoomStateEntity() }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RoomStateEntity())

  val furniture: StateFlow<List<RoomFurnitureEntity>> =
    repository.furniture.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val memories: StateFlow<List<MemoryEntity>> =
    repository.memories.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val capsules: StateFlow<List<TimeCapsuleEntity>> =
    repository.capsules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val chatMessages: StateFlow<List<ChatMessageEntity>> =
    repository.chatMessages.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5_000),
      emptyList(),
    )

  val reels: StateFlow<List<ReelEntity>> =
    repository.reels.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val reelComments: StateFlow<List<ReelCommentEntity>> =
    repository.reelComments.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5_000),
      emptyList(),
    )

  val boards: StateFlow<List<BoardEntity>> =
    repository.boards.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val explorePins: StateFlow<List<ExplorePinEntity>> =
    repository.explorePins.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5_000),
      emptyList(),
    )

  val tracks: StateFlow<List<PlaylistTrackEntity>> =
    repository.tracks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val cinemaTitles: StateFlow<List<CinemaTitleEntity>> =
    repository.cinemaTitles.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5_000),
      emptyList(),
    )

  val twoMinds: StateFlow<List<TwoMindsEntity>> =
    repository.twoMinds.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  val profiles: StateFlow<List<UserProfileEntity>> =
    repository.profiles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  private val _musicPlayer = MutableStateFlow(MusicPlayerState())
  val musicPlayer: StateFlow<MusicPlayerState> = _musicPlayer.asStateFlow()

  private val _watchTogether = MutableStateFlow(WatchTogetherState())
  val watchTogether: StateFlow<WatchTogetherState> = _watchTogether.asStateFlow()

  init {
    viewModelScope.launch { repository.seedIfEmpty() }
  }

  // Account & Room State Actions
  fun switchActiveUserSlot() {
    val current = roomState.value
    val nextSlot = if (current.activeUserSlot == "A") "B" else "A"
    viewModelScope.launch { repository.upsertRoomState(current.copy(activeUserSlot = nextSlot)) }
  }

  fun updateRoomName(newName: String) {
    val trimmed = newName.trim()
    if (trimmed.isEmpty()) return
    viewModelScope.launch {
      repository.upsertRoomState(roomState.value.copy(roomName = trimmed.take(30)))
    }
  }

  fun toggleOnlinePrivacy() {
    val current = roomState.value
    viewModelScope.launch {
      repository.upsertRoomState(current.copy(showOnlineStatus = !current.showOnlineStatus))
    }
  }

  fun setWallpaper(theme: String) {
    viewModelScope.launch {
      repository.upsertRoomState(roomState.value.copy(wallpaperTheme = theme))
    }
  }

  fun setLighting(mode: String) {
    viewModelScope.launch { repository.upsertRoomState(roomState.value.copy(lightingMode = mode)) }
  }

  fun cyclePandaMood() {
    val moods = listOf("Cozy", "Sleepy", "Excited", "Love", "Snack Time")
    val current = roomState.value.pandaMood
    val next = moods[(moods.indexOf(current) + 1) % moods.size]
    viewModelScope.launch { repository.upsertRoomState(roomState.value.copy(pandaMood = next)) }
  }

  fun cycleTeddyMood() {
    val moods = listOf("Happy", "Hugging", "Dreamy", "Playful", "Listening")
    val current = roomState.value.teddyMood
    val next = moods[(moods.indexOf(current) + 1) % moods.size]
    viewModelScope.launch { repository.upsertRoomState(roomState.value.copy(teddyMood = next)) }
  }

  fun moveFurniture(item: RoomFurnitureEntity, xFraction: Float, yFraction: Float) {
    val clampedX = xFraction.coerceIn(0.08f, 0.84f)
    val clampedY = yFraction.coerceIn(0.24f, 0.84f)
    viewModelScope.launch {
      repository.updateFurniture(item.copy(xFraction = clampedX, yFraction = clampedY))
    }
  }

  fun toggleFurniturePlaced(item: RoomFurnitureEntity) {
    viewModelScope.launch { repository.updateFurniture(item.copy(isPlaced = !item.isPlaced)) }
  }

  fun setFramePhoto(uriString: String) {
    val frame = furniture.value.firstOrNull { it.id == "frame" } ?: return
    viewModelScope.launch {
      repository.updateFurniture(frame.copy(customPhotoUri = uriString, isPlaced = true))
    }
  }

  // Memories & Capsules
  fun addMemory(title: String, note: String, moodTag: String, photoUri: String?) {
    if (title.isBlank()) return
    viewModelScope.launch {
      repository.insertMemory(
        MemoryEntity(
          title = title.trim(),
          note = note.trim(),
          dateLabel = "Today",
          moodTag = moodTag,
          authorSlot = roomState.value.activeUserSlot,
          photoUri = photoUri,
        )
      )
    }
  }

  fun deleteMemory(id: Int) {
    viewModelScope.launch { repository.deleteMemory(id) }
  }

  fun addTimeCapsule(title: String, message: String, unlockDate: String) {
    if (title.isBlank() || message.isBlank()) return
    viewModelScope.launch {
      repository.insertCapsule(
        TimeCapsuleEntity(
          title = title.trim(),
          secretMessage = message.trim(),
          unlockDateLabel = unlockDate.ifBlank { "Next Year" },
          isUnlocked = false,
          authorSlot = roomState.value.activeUserSlot,
        )
      )
    }
  }

  fun unlockCapsule(capsule: TimeCapsuleEntity) {
    viewModelScope.launch { repository.updateCapsule(capsule.copy(isUnlocked = true)) }
  }

  // Private Chat
  fun sendChatMessage(
    text: String,
    attachmentType: String? = null,
    attachmentLabel: String? = null,
    replyPreview: String? = null,
  ) {
    if (text.isBlank() && attachmentLabel == null) return
    viewModelScope.launch {
      repository.insertMessage(
        ChatMessageEntity(
          senderSlot = roomState.value.activeUserSlot,
          text = text.trim(),
          attachmentType = attachmentType,
          attachmentLabel = attachmentLabel,
          replyPreview = replyPreview,
        )
      )
    }
  }

  fun reactToMessage(message: ChatMessageEntity, emoji: String) {
    viewModelScope.launch {
      val next = if (message.reactionEmoji == emoji) null else emoji
      repository.updateMessage(message.copy(reactionEmoji = next))
    }
  }

  fun deleteMessage(id: Int) {
    viewModelScope.launch { repository.deleteMessage(id) }
  }

  // Reels & Create
  fun toggleReelLike(reel: ReelEntity) {
    val slot = roomState.value.activeUserSlot
    val updated =
      if (slot == "A") reel.copy(likedByA = !reel.likedByA) else reel.copy(likedByB = !reel.likedByB)
    viewModelScope.launch { repository.updateReel(updated) }
  }

  fun toggleReelSave(reel: ReelEntity) {
    viewModelScope.launch { repository.updateReel(reel.copy(isSaved = !reel.isSaved)) }
  }

  fun addReelComment(reelId: Int, text: String) {
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.insertReelComment(
        ReelCommentEntity(
          reelId = reelId,
          authorSlot = roomState.value.activeUserSlot,
          text = text.trim(),
        )
      )
    }
  }

  fun publishOrDraftReel(
    caption: String,
    audioTitle: String,
    hashtags: String,
    filterTag: String,
    mediaUri: String?,
    isDraft: Boolean,
  ) {
    viewModelScope.launch {
      repository.insertReel(
        ReelEntity(
          authorSlot = roomState.value.activeUserSlot,
          caption = caption.ifBlank { "Captured in Vibely Studio" },
          audioTitle = audioTitle.ifBlank { "Original Room Audio" },
          hashtags = hashtags.ifBlank { "#vibely #privateuniverse" },
          filterTag = filterTag,
          isDraft = isDraft,
          mediaUri = mediaUri,
          coverStyle = (reels.value.size) % 3,
        )
      )
    }
  }

  // Explore & Boards
  fun createBoard(name: String, subtitle: String) {
    if (name.isBlank()) return
    val tints = listOf(0xFFFCDCE6, 0xFFFFE5D6, 0xFFEBE4FA, 0xFFDDF5EA)
    viewModelScope.launch {
      repository.insertBoard(
        BoardEntity(
          name = name.trim(),
          subtitle = subtitle.ifBlank { "Personal Vibely collection" },
          accentHex = tints[boards.value.size % tints.size],
        )
      )
    }
  }

  fun savePinToBoard(pin: ExplorePinEntity, boardId: Int?) {
    viewModelScope.launch { repository.updateExplorePin(pin.copy(savedBoardId = boardId)) }
  }

  // Music Room
  fun selectTrack(index: Int) {
    _musicPlayer.update { it.copy(currentTrackIndex = index, isPlaying = true, progressFraction = 0.08f) }
  }

  fun togglePlayPause() {
    _musicPlayer.update { it.copy(isPlaying = !it.isPlaying) }
  }

  fun nextTrack() {
    val count = tracks.value.size.coerceAtLeast(1)
    _musicPlayer.update {
      it.copy(currentTrackIndex = (it.currentTrackIndex + 1) % count, progressFraction = 0.05f)
    }
  }

  fun prevTrack() {
    val count = tracks.value.size.coerceAtLeast(1)
    _musicPlayer.update {
      it.copy(
        currentTrackIndex = (it.currentTrackIndex - 1 + count) % count,
        progressFraction = 0.05f,
      )
    }
  }

  fun toggleShuffle() {
    _musicPlayer.update { it.copy(isShuffle = !it.isShuffle) }
  }

  fun toggleRepeat() {
    _musicPlayer.update { it.copy(isRepeat = !it.isRepeat) }
  }

  fun seekTrack(fraction: Float) {
    _musicPlayer.update { it.copy(progressFraction = fraction.coerceIn(0f, 1f)) }
  }

  fun toggleTrackFavorite(track: PlaylistTrackEntity) {
    viewModelScope.launch { repository.updateTrack(track.copy(isFavorite = !track.isFavorite)) }
  }

  fun addTrackToOurPlaylist(title: String, artist: String) {
    if (title.isBlank()) return
    val tints = listOf(0xFFFCDCE6, 0xFFEBE4FA, 0xFFFFE5D6, 0xFFDDF5EA)
    viewModelScope.launch {
      repository.insertTrack(
        PlaylistTrackEntity(
          title = title.trim(),
          artist = artist.ifBlank { "Shared Selection" },
          album = "Our Playlist",
          durationSec = 205,
          addedBySlot = roomState.value.activeUserSlot,
          tintHex = tints[tracks.value.size % tints.size],
        )
      )
    }
  }

  // Cinema & Watch Together
  fun toggleWatchlist(title: CinemaTitleEntity) {
    viewModelScope.launch {
      repository.updateCinemaTitle(title.copy(inWatchlist = !title.inWatchlist))
    }
  }

  fun startWatchTogether(movieId: String) {
    val movie = cinemaTitles.value.firstOrNull { it.id == movieId }
    _watchTogether.update {
      it.copy(
        activeMovieId = movieId,
        isPlaying = true,
        positionFraction = movie?.progressFraction ?: 0.1f,
      )
    }
  }

  fun toggleWatchTogetherPlayPause() {
    _watchTogether.update { it.copy(isPlaying = !it.isPlaying) }
  }

  fun seekWatchTogether(fraction: Float) {
    val clamped = fraction.coerceIn(0f, 1f)
    _watchTogether.update { it.copy(positionFraction = clamped) }
    val movieId = _watchTogether.value.activeMovieId ?: return
    val movie = cinemaTitles.value.firstOrNull { it.id == movieId } ?: return
    viewModelScope.launch { repository.updateCinemaTitle(movie.copy(progressFraction = clamped)) }
  }

  fun sendWatchReaction(emoji: String) {
    _watchTogether.update {
      it.copy(recentReactions = (listOf(emoji) + it.recentReactions).take(6))
    }
  }

  fun sendWatchChat(message: String) {
    if (message.isBlank()) return
    val senderName =
      profiles.value.firstOrNull { it.slot == roomState.value.activeUserSlot }?.displayName ?: "You"
    _watchTogether.update { it.copy(roomChat = it.roomChat + (senderName to message.trim())) }
  }

  // Two Minds
  fun submitTwoMindsAnswer(item: TwoMindsEntity, answer: String) {
    if (answer.isBlank()) return
    val slot = roomState.value.activeUserSlot
    val updated =
      if (slot == "A") item.copy(answerA = answer.trim()) else item.copy(answerB = answer.trim())
    viewModelScope.launch { repository.updateTwoMind(updated) }
  }

  // Profile & Personal Corner
  fun updateActiveProfile(displayName: String, bio: String, favoriteSong: String, diaryNote: String) {
    val slot = roomState.value.activeUserSlot
    val current = profiles.value.firstOrNull { it.slot == slot } ?: return
    viewModelScope.launch {
      repository.updateProfile(
        current.copy(
          displayName = displayName.trim().ifBlank { current.displayName },
          bio = bio.trim(),
          favoriteSong = favoriteSong.trim(),
          diaryNote = diaryNote.trim(),
        )
      )
    }
  }
}
