package com.example.vibely.ui.reels

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.CinemaAccentLavender
import com.example.ui.theme.CinemaAccentPeach
import com.example.ui.theme.CinemaAccentPink
import com.example.ui.theme.CinemaBg
import com.example.ui.theme.CinemaCard
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaText
import com.example.vibely.data.ReelCommentEntity
import com.example.vibely.data.ReelEntity
import com.example.vibely.data.UserProfileEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelsScreen(
  reels: List<ReelEntity>,
  comments: List<ReelCommentEntity>,
  profiles: List<UserProfileEntity>,
  activeUserSlot: String,
  onToggleLike: (ReelEntity) -> Unit,
  onToggleSave: (ReelEntity) -> Unit,
  onAddComment: (Int, String) -> Unit,
  onShareToChat: (ReelEntity) -> Unit,
  onOpenCreate: () -> Unit,
  bottomContentPadding: PaddingValues,
) {
  var selectedFeed by remember { mutableStateOf("For You") }
  var qualityMode by remember { mutableStateOf("Auto • Saver") }
  var activeCommentReel by remember { mutableStateOf<ReelEntity?>(null) }
  var isPaused by remember { mutableStateOf(false) }

  val filteredReels =
    remember(reels, selectedFeed) {
      when (selectedFeed) {
        "Drafts" -> reels.filter { it.isDraft }
        "Following" -> reels.filter { !it.isDraft && it.authorSlot != activeUserSlot }.ifEmpty { reels.filter { !it.isDraft } }
        else -> reels.filter { !it.isDraft }
      }
    }

  Box(modifier = Modifier.fillMaxSize().background(CinemaBg)) {
    if (filteredReels.isEmpty()) {
      Column(
        modifier = Modifier.align(Alignment.Center).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text("No Reels in $selectedFeed yet", style = MaterialTheme.typography.titleLarge, color = CinemaText)
        Text(
          "Capture a cozy moment in Create Studio to share between your two accounts.",
          style = MaterialTheme.typography.bodyMedium,
          color = Color.White.copy(alpha = 0.7f),
        )
        Surface(
          onClick = onOpenCreate,
          shape = CircleShape,
          color = CinemaAccentPink,
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Rounded.Add, contentDescription = null, tint = CinemaBg)
            Spacer(Modifier.width(6.dp))
            Text("Create Reel", style = MaterialTheme.typography.labelLarge, color = CinemaBg)
          }
        }
      }
    } else {
      val pagerState = rememberPagerState(pageCount = { filteredReels.size })
      VerticalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize().testTag("reels_vertical_pager"),
      ) { page ->
        val reel = filteredReels[page]
        val author = profiles.firstOrNull { it.slot == reel.authorSlot }
        val likeCount = (if (reel.likedByA) 1 else 0) + (if (reel.likedByB) 1 else 0)
        val isLikedByMe = if (activeUserSlot == "A") reel.likedByA else reel.likedByB
        val reelComments = comments.filter { it.reelId == reel.id }

        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .clickable { isPaused = !isPaused }
        ) {
          // 9:16 Visual Reel Surface
          if (reel.mediaUri != null) {
            AsyncImage(
              model = reel.mediaUri,
              contentDescription = reel.caption,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          } else {
            val resId =
              when (reel.coverStyle % 3) {
                0 -> R.drawable.img_explore_aesthetic_1795279160167
                1 -> R.drawable.img_music_cover_1795279158690
                else -> R.drawable.img_virtual_room_bg_1795279159875
              }
            Image(
              painter = painterResource(resId),
              contentDescription = reel.caption,
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
          }

          // Cinematic bottom & top vignette
          Box(
            modifier =
              Modifier
                .fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    colors =
                      listOf(
                        CinemaBg.copy(alpha = 0.65f),
                        Color.Transparent,
                        Color.Transparent,
                        CinemaBg.copy(alpha = 0.88f),
                      )
                  )
                )
          )

          if (isPaused) {
            Surface(
              shape = CircleShape,
              color = CinemaBg.copy(alpha = 0.62f),
              modifier = Modifier.align(Alignment.Center).size(72.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "Paused", tint = Color.White, modifier = Modifier.size(40.dp))
              }
            }
          }

          // Right Engagement Controls (Strictly two-account real counts)
          Column(
            modifier =
              Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 14.dp, bottom = bottomContentPadding.calculateBottomPadding() + 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
          ) {
            ReelActionColumn(
              icon = if (isLikedByMe) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
              label = "$likeCount/2",
              tint = if (isLikedByMe) CinemaAccentPink else Color.White,
              testTag = "reel_like_${reel.id}",
              onClick = { onToggleLike(reel) },
            )
            ReelActionColumn(
              icon = Icons.Outlined.ChatBubbleOutline,
              label = reelComments.size.toString(),
              tint = Color.White,
              testTag = "reel_comment_${reel.id}",
              onClick = { activeCommentReel = reel },
            )
            ReelActionColumn(
              icon = if (reel.isSaved) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
              label = if (reel.isSaved) "Saved" else "Save",
              tint = if (reel.isSaved) CinemaAccentPeach else Color.White,
              testTag = "reel_save_${reel.id}",
              onClick = { onToggleSave(reel) },
            )
            ReelActionColumn(
              icon = Icons.Rounded.Send,
              label = "Chat",
              tint = CinemaAccentLavender,
              testTag = "reel_share_${reel.id}",
              onClick = { onShareToChat(reel) },
            )
          }

          // Bottom Caption, Author & Audio Attribution
          Column(
            modifier =
              Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.78f)
                .padding(start = 18.dp, bottom = bottomContentPadding.calculateBottomPadding() + 26.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Surface(
                shape = CircleShape,
                color = CinemaAccentPink,
                modifier = Modifier.size(34.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Text(
                    author?.displayName?.firstOrNull()?.toString() ?: reel.authorSlot,
                    style = MaterialTheme.typography.labelLarge,
                    color = CinemaBg,
                  )
                }
              }
              Column {
                Text(
                  text = author?.displayName ?: "Account ${reel.authorSlot}",
                  style = MaterialTheme.typography.titleMedium,
                  color = Color.White,
                )
                Text(
                  text = "Private Duo Reel • ${reel.filterTag}",
                  style = MaterialTheme.typography.labelSmall,
                  color = CinemaAccentPeach,
                )
              }
            }

            Text(text = reel.caption, style = MaterialTheme.typography.bodyLarge, color = Color.White)
            Text(text = reel.hashtags, style = MaterialTheme.typography.labelMedium, color = CinemaAccentLavender)

            Surface(
              shape = CircleShape,
              color = Color.White.copy(alpha = 0.14f),
              border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = CinemaAccentPink, modifier = Modifier.size(16.dp))
                Text(reel.audioTitle, style = MaterialTheme.typography.labelSmall, color = Color.White)
              }
            }
          }
        }
      }
    }

    // Top Floating Reels Bar (For You / Following / Drafts + Quality + Create)
    Row(
      modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("For You", "Following", "Drafts").forEach { tab ->
          val selected = selectedFeed == tab
          Surface(
            onClick = { selectedFeed = tab },
            shape = CircleShape,
            color = if (selected) CinemaAccentPink else Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.testTag("reels_tab_$tab"),
          ) {
            Text(
              text = tab,
              style = MaterialTheme.typography.labelMedium,
              color = if (selected) CinemaBg else Color.White,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            )
          }
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(
          onClick = {
            qualityMode =
              when (qualityMode) {
                "Auto • Saver" -> "1080p Crisp"
                "1080p Crisp" -> "720p Lite"
                else -> "Auto • Saver"
              }
          },
          shape = CircleShape,
          color = Color.Black.copy(alpha = 0.45f),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(Icons.Rounded.Tune, contentDescription = "Quality", tint = Color.White, modifier = Modifier.size(14.dp))
            Text(qualityMode, style = MaterialTheme.typography.labelSmall, color = Color.White)
          }
        }

        Surface(
          onClick = onOpenCreate,
          shape = CircleShape,
          color = CinemaAccentPink,
          modifier = Modifier.size(34.dp).testTag("reels_create_button"),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Add, contentDescription = "Create Reel", tint = CinemaBg, modifier = Modifier.size(20.dp))
          }
        }
      }
    }
  }

  // Comments Bottom Sheet
  activeCommentReel?.let { reel ->
    val sheetComments = comments.filter { it.reelId == reel.id }
    var draftComment by remember { mutableStateOf("") }
    ModalBottomSheet(
      onDismissRequest = { activeCommentReel = null },
      containerColor = CinemaSurface,
      contentColor = CinemaText,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text("Private Comments", style = MaterialTheme.typography.titleLarge, color = CinemaText)
        if (sheetComments.isEmpty()) {
          Text("Leave a sweet note on this reel.", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.65f))
        } else {
          sheetComments.forEach { comment ->
            val name = profiles.firstOrNull { it.slot == comment.authorSlot }?.displayName ?: comment.authorSlot
            Surface(shape = RoundedCornerShape(14.dp), color = CinemaCard, modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(name, style = MaterialTheme.typography.labelMedium, color = CinemaAccentPink)
                Text(comment.text, style = MaterialTheme.typography.bodyMedium, color = CinemaText)
              }
            }
          }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = draftComment,
            onValueChange = { draftComment = it },
            placeholder = { Text("Add a private reply...") },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          IconButton(
            onClick = {
              if (draftComment.isNotBlank()) {
                onAddComment(reel.id, draftComment)
                draftComment = ""
              }
            },
            modifier = Modifier.minimumInteractiveComponentSize().clip(CircleShape).background(CinemaAccentPink),
          ) {
            Icon(Icons.Rounded.Send, contentDescription = stringResource(R.string.cd_send_message), tint = CinemaBg)
          }
        }
        Spacer(Modifier.height(20.dp))
      }
    }
  }
}

@Composable
private fun ReelActionColumn(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  tint: Color,
  testTag: String,
  onClick: () -> Unit,
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier.clickable(onClick = onClick).testTag(testTag),
  ) {
    Surface(
      shape = CircleShape,
      color = Color.Black.copy(alpha = 0.45f),
      modifier = Modifier.size(48.dp),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
      }
    }
    Spacer(Modifier.height(3.dp))
    Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White)
  }
}
