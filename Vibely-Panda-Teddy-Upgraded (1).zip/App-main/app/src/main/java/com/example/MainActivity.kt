package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SlowMotionVideo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SlowMotionVideo
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.CinemaAccentPink
import com.example.ui.theme.CinemaBg
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.ui.theme.VibelyTheme
import com.example.vibely.ui.chat.PrivateChatScreen
import com.example.vibely.ui.cinema.CinemaScreen
import com.example.vibely.ui.create.CreateStudioScreen
import com.example.vibely.ui.explore.ExploreBoardsScreen
import com.example.vibely.ui.extras.OurMemoriesScreen
import com.example.vibely.ui.extras.PlayTogetherScreen
import com.example.vibely.ui.extras.TimeCapsuleScreen
import com.example.vibely.ui.home.VirtualHomeScreen
import com.example.vibely.ui.music.MusicRoomScreen
import com.example.vibely.ui.profile.ProfileScreen
import com.example.vibely.ui.reels.ReelsScreen
import com.example.vibely.viewmodel.VibelyViewModel

object VibelyRoutes {
  const val HOME = "home"
  const val REELS = "reels"
  const val CREATE = "create"
  const val EXPLORE = "explore"
  const val PROFILE = "profile"
  const val CHAT = "chat"
  const val MEMORIES = "memories"
  const val MUSIC = "music"
  const val CINEMA = "cinema"
  const val PLAY = "play"
  const val CAPSULE = "capsule"
}

private data class MainNavTab(
  val route: String,
  val labelRes: Int,
  val activeIcon: ImageVector,
  val inactiveIcon: ImageVector,
)

private val mainTabs =
  listOf(
    MainNavTab(VibelyRoutes.HOME, R.string.nav_home, Icons.Rounded.Home, Icons.Outlined.Home),
    MainNavTab(VibelyRoutes.REELS, R.string.nav_reels, Icons.Rounded.SlowMotionVideo, Icons.Outlined.SlowMotionVideo),
    MainNavTab(VibelyRoutes.CREATE, R.string.nav_create, Icons.Rounded.Add, Icons.Rounded.Add),
    MainNavTab(VibelyRoutes.EXPLORE, R.string.nav_explore, Icons.Rounded.Explore, Icons.Outlined.Explore),
    MainNavTab(VibelyRoutes.PROFILE, R.string.nav_profile, Icons.Rounded.Person, Icons.Outlined.Person),
  )

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      VibelyTheme {
        VibelyAppRoot()
      }
    }
  }
}

@Composable
fun VibelyAppRoot(viewModel: VibelyViewModel = viewModel()) {
  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route ?: VibelyRoutes.HOME

  val roomState by viewModel.roomState.collectAsStateWithLifecycle()
  val furniture by viewModel.furniture.collectAsStateWithLifecycle()
  val memories by viewModel.memories.collectAsStateWithLifecycle()
  val capsules by viewModel.capsules.collectAsStateWithLifecycle()
  val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
  val reels by viewModel.reels.collectAsStateWithLifecycle()
  val reelComments by viewModel.reelComments.collectAsStateWithLifecycle()
  val boards by viewModel.boards.collectAsStateWithLifecycle()
  val explorePins by viewModel.explorePins.collectAsStateWithLifecycle()
  val tracks by viewModel.tracks.collectAsStateWithLifecycle()
  val cinemaTitles by viewModel.cinemaTitles.collectAsStateWithLifecycle()
  val twoMinds by viewModel.twoMinds.collectAsStateWithLifecycle()
  val profiles by viewModel.profiles.collectAsStateWithLifecycle()
  val musicPlayer by viewModel.musicPlayer.collectAsStateWithLifecycle()
  val watchTogether by viewModel.watchTogether.collectAsStateWithLifecycle()

  val showBottomBar = currentRoute in mainTabs.map { it.route }
  val isDarkNavSurface = currentRoute == VibelyRoutes.REELS || currentRoute == VibelyRoutes.CREATE
  val bottomBarPadding = PaddingValues(bottom = 92.dp)

  Box(modifier = Modifier.fillMaxSize()) {
    NavHost(
      navController = navController,
      startDestination = VibelyRoutes.HOME,
      modifier = Modifier.fillMaxSize(),
    ) {
      composable(VibelyRoutes.HOME) {
        VirtualHomeScreen(
          roomState = roomState,
          furniture = furniture,
          profiles = profiles,
          unreadChatCount = chatMessages.size,
          onSwitchAccount = viewModel::switchActiveUserSlot,
          onTogglePrivacy = viewModel::toggleOnlinePrivacy,
          onUpdateRoomName = viewModel::updateRoomName,
          onSetWallpaper = viewModel::setWallpaper,
          onSetLighting = viewModel::setLighting,
          onCyclePandaMood = viewModel::cyclePandaMood,
          onCycleTeddyMood = viewModel::cycleTeddyMood,
          onMoveFurniture = viewModel::moveFurniture,
          onToggleFurniturePlaced = viewModel::toggleFurniturePlaced,
          onSetFramePhoto = viewModel::setFramePhoto,
          onOpenChat = { navController.navigate(VibelyRoutes.CHAT) },
          onOpenMemories = { navController.navigate(VibelyRoutes.MEMORIES) },
          onOpenMusic = { navController.navigate(VibelyRoutes.MUSIC) },
          onOpenSnapshots = {
            navController.navigate(VibelyRoutes.CREATE) {
              popUpTo(navController.graph.findStartDestination().id) { saveState = true }
              launchSingleTop = true
              restoreState = true
            }
          },
          onOpenCinema = { navController.navigate(VibelyRoutes.CINEMA) },
          onOpenPlayTogether = { navController.navigate(VibelyRoutes.PLAY) },
          onOpenTimeCapsule = { navController.navigate(VibelyRoutes.CAPSULE) },
          bottomContentPadding = bottomBarPadding,
        )
      }

      composable(VibelyRoutes.REELS) {
        ReelsScreen(
          reels = reels,
          comments = reelComments,
          profiles = profiles,
          activeUserSlot = roomState.activeUserSlot,
          onToggleLike = viewModel::toggleReelLike,
          onToggleSave = viewModel::toggleReelSave,
          onAddComment = viewModel::addReelComment,
          onShareToChat = { reel ->
            viewModel.sendChatMessage(
              text = "Shared a Reel with you!",
              attachmentType = "reel",
              attachmentLabel = reel.caption.take(32),
            )
            navController.navigate(VibelyRoutes.CHAT)
          },
          onOpenCreate = {
            navController.navigate(VibelyRoutes.CREATE) {
              popUpTo(navController.graph.findStartDestination().id) { saveState = true }
              launchSingleTop = true
              restoreState = true
            }
          },
          bottomContentPadding = bottomBarPadding,
        )
      }

      composable(VibelyRoutes.CREATE) {
        CreateStudioScreen(
          onPublishReel = viewModel::publishOrDraftReel,
          onSaveMemory = viewModel::addMemory,
          bottomContentPadding = bottomBarPadding,
        )
      }

      composable(VibelyRoutes.EXPLORE) {
        ExploreBoardsScreen(
          pins = explorePins,
          boards = boards,
          onSavePinToBoard = viewModel::savePinToBoard,
          onCreateBoard = viewModel::createBoard,
          bottomContentPadding = bottomBarPadding,
        )
      }

      composable(VibelyRoutes.PROFILE) {
        ProfileScreen(
          roomState = roomState,
          profiles = profiles,
          savedPinsCount = explorePins.count { it.savedBoardId != null },
          favoriteTracksCount = tracks.count { it.isFavorite },
          savedReelsCount = reels.count { it.isSaved },
          onSwitchAccount = viewModel::switchActiveUserSlot,
          onTogglePrivacy = viewModel::toggleOnlinePrivacy,
          onSaveProfile = viewModel::updateActiveProfile,
          bottomContentPadding = bottomBarPadding,
        )
      }

      composable(VibelyRoutes.CHAT) {
        PrivateChatScreen(
          messages = chatMessages,
          profiles = profiles,
          activeUserSlot = roomState.activeUserSlot,
          onSwitchAccount = viewModel::switchActiveUserSlot,
          onSendMessage = viewModel::sendChatMessage,
          onReact = viewModel::reactToMessage,
          onDelete = viewModel::deleteMessage,
          onBack = { navController.popBackStack() },
        )
      }

      composable(VibelyRoutes.MEMORIES) {
        OurMemoriesScreen(
          memories = memories,
          profiles = profiles,
          onAddMemory = viewModel::addMemory,
          onDeleteMemory = viewModel::deleteMemory,
          onBack = { navController.popBackStack() },
        )
      }

      composable(VibelyRoutes.MUSIC) {
        MusicRoomScreen(
          tracks = tracks,
          playerState = musicPlayer,
          profiles = profiles,
          onSelectTrack = viewModel::selectTrack,
          onTogglePlayPause = viewModel::togglePlayPause,
          onNext = viewModel::nextTrack,
          onPrev = viewModel::prevTrack,
          onToggleShuffle = viewModel::toggleShuffle,
          onToggleRepeat = viewModel::toggleRepeat,
          onSeek = viewModel::seekTrack,
          onToggleFavorite = viewModel::toggleTrackFavorite,
          onAddTrack = viewModel::addTrackToOurPlaylist,
          onBack = { navController.popBackStack() },
        )
      }

      composable(VibelyRoutes.CINEMA) {
        CinemaScreen(
          titles = cinemaTitles,
          watchTogether = watchTogether,
          onToggleWatchlist = viewModel::toggleWatchlist,
          onStartWatchTogether = viewModel::startWatchTogether,
          onToggleWatchPlayPause = viewModel::toggleWatchTogetherPlayPause,
          onSeekWatch = viewModel::seekWatchTogether,
          onSendReaction = viewModel::sendWatchReaction,
          onSendWatchChat = viewModel::sendWatchChat,
          onBack = { navController.popBackStack() },
        )
      }

      composable(VibelyRoutes.PLAY) {
        PlayTogetherScreen(
          twoMinds = twoMinds,
          profiles = profiles,
          activeUserSlot = roomState.activeUserSlot,
          onSubmitTwoMinds = viewModel::submitTwoMindsAnswer,
          onSwitchAccount = viewModel::switchActiveUserSlot,
          onBack = { navController.popBackStack() },
        )
      }

      composable(VibelyRoutes.CAPSULE) {
        TimeCapsuleScreen(
          capsules = capsules,
          profiles = profiles,
          onCreateCapsule = viewModel::addTimeCapsule,
          onUnlockCapsule = viewModel::unlockCapsule,
          onBack = { navController.popBackStack() },
        )
      }
    }

    // Floating Pastel Glassmorphic 5-Tab Bottom Navigation Bar
    if (showBottomBar) {
      VibelyBottomNavBar(
        currentRoute = currentRoute,
        isDarkSurface = isDarkNavSurface,
        onSelectTab = { route ->
          navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
          }
        },
        modifier =
          Modifier
            .align(Alignment.BottomCenter)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
      )
    }
  }
}

@Composable
private fun VibelyBottomNavBar(
  currentRoute: String,
  isDarkSurface: Boolean,
  onSelectTab: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(30.dp),
    color = if (isDarkSurface) CinemaSurface.copy(alpha = 0.92f) else Color.White.copy(alpha = 0.94f),
    border =
      BorderStroke(
        width = 1.dp,
        color = if (isDarkSurface) Color.White.copy(alpha = 0.14f) else VibelyPinkSoft,
      ),
    shadowElevation = 10.dp,
    modifier = modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp),
      horizontalArrangement = Arrangement.SpaceAround,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      mainTabs.forEach { tab ->
        val selected = currentRoute == tab.route
        val label = stringResource(tab.labelRes)
        val isCreateCenter = tab.route == VibelyRoutes.CREATE

        if (isCreateCenter) {
          Surface(
            onClick = { onSelectTab(tab.route) },
            shape = CircleShape,
            color = if (selected) CinemaAccentPink else VibelyPink,
            shadowElevation = 4.dp,
            modifier = Modifier.size(48.dp).testTag("nav_${tab.route}"),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = tab.activeIcon,
                contentDescription = label,
                tint = if (selected && isDarkSurface) CinemaBg else Color.White,
                modifier = Modifier.size(26.dp),
              )
            }
          }
        } else {
          Column(
            modifier =
              Modifier
                .clip(RoundedCornerShape(18.dp))
                .clickable { onSelectTab(tab.route) }
                .padding(horizontal = 10.dp, vertical = 4.dp)
                .testTag("nav_${tab.route}"),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
          ) {
            Icon(
              imageVector = if (selected) tab.activeIcon else tab.inactiveIcon,
              contentDescription = label,
              tint =
                when {
                  selected && isDarkSurface -> CinemaAccentPink
                  selected -> VibelyPink
                  isDarkSurface -> Color.White.copy(alpha = 0.65f)
                  else -> VibelyInk.copy(alpha = 0.62f)
                },
              modifier = Modifier.size(22.dp),
            )
            Text(
              text = label,
              style = MaterialTheme.typography.labelSmall,
              color =
                when {
                  selected && isDarkSurface -> CinemaAccentPink
                  selected -> VibelyPink
                  isDarkSurface -> Color.White.copy(alpha = 0.65f)
                  else -> VibelyInk.copy(alpha = 0.62f)
                },
            )
          }
        }
      }
    }
  }
}
