package com.example.vibely.ui.cinema

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CinemaAccentLavender
import com.example.ui.theme.CinemaAccentPeach
import com.example.ui.theme.CinemaAccentPink
import com.example.ui.theme.CinemaBg
import com.example.ui.theme.CinemaCard
import com.example.ui.theme.CinemaMuted
import com.example.ui.theme.CinemaSurface
import com.example.ui.theme.CinemaText
import com.example.vibely.data.CinemaTitleEntity
import com.example.vibely.viewmodel.WatchTogetherState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CinemaScreen(
  titles: List<CinemaTitleEntity>,
  watchTogether: WatchTogetherState,
  onToggleWatchlist: (CinemaTitleEntity) -> Unit,
  onStartWatchTogether: (String) -> Unit,
  onToggleWatchPlayPause: () -> Unit,
  onSeekWatch: (Float) -> Unit,
  onSendReaction: (String) -> Unit,
  onSendWatchChat: (String) -> Unit,
  onBack: () -> Unit,
) {
  var selectedMovie by remember { mutableStateOf<CinemaTitleEntity?>(null) }
  var inWatchRoom by remember { mutableStateOf(false) }
  val featured = titles.firstOrNull()

  if (inWatchRoom) {
    val activeMovie = titles.firstOrNull { it.id == watchTogether.activeMovieId } ?: featured
    WatchTogetherRoomView(
      movie = activeMovie,
      state = watchTogether,
      onTogglePlayPause = onToggleWatchPlayPause,
      onSeek = onSeekWatch,
      onReaction = onSendReaction,
      onSendChat = onSendWatchChat,
      onLeaveRoom = { inWatchRoom = false },
    )
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().background(CinemaBg).statusBarsPadding().navigationBarsPadding(),
    contentPadding = PaddingValues(bottom = 28.dp),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    // Top Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize().testTag("cinema_back_button")) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = CinemaText)
          }
          Column {
            Text("Vibely Cinema", style = MaterialTheme.typography.headlineSmall, color = CinemaText)
            Text("Discovery & Watch Together Lounge", style = MaterialTheme.typography.labelSmall, color = CinemaAccentLavender)
          }
        }
        Surface(shape = CircleShape, color = CinemaCard) {
          Text(
            "Authorized & Archive",
            style = MaterialTheme.typography.labelSmall,
            color = CinemaAccentPeach,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          )
        }
      }
    }

    // Large Featured Banner
    if (featured != null) {
      item {
        Box(
          modifier =
            Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp)
              .height(230.dp)
              .clip(RoundedCornerShape(26.dp))
              .clickable { selectedMovie = featured }
              .testTag("cinema_featured_banner")
        ) {
          Image(
            painter = painterResource(R.drawable.img_cinema_featured_1795279160527),
            contentDescription = featured.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier =
              Modifier
                .fillMaxSize()
                .background(
                  Brush.verticalGradient(listOf(Color.Transparent, CinemaBg.copy(alpha = 0.92f)))
                )
          )
          Column(
            modifier = Modifier.align(Alignment.BottomStart).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(featured.sourceLabel, style = MaterialTheme.typography.labelSmall, color = CinemaAccentPeach)
            Text("${featured.title} (${featured.year})", style = MaterialTheme.typography.headlineMedium, color = CinemaText)
            Text("${featured.genre} • ${featured.duration}", style = MaterialTheme.typography.bodyMedium, color = CinemaMuted)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Button(
                onClick = {
                  onStartWatchTogether(featured.id)
                  inWatchRoom = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = CinemaAccentPink, contentColor = CinemaBg),
                shape = CircleShape,
                modifier = Modifier.testTag("cinema_watch_together_cta"),
              ) {
                Icon(Icons.Rounded.Group, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Watch Together")
              }
              OutlinedButton(
                onClick = { onToggleWatchlist(featured) },
                border = BorderStroke(1.dp, CinemaAccentLavender),
                shape = CircleShape,
              ) {
                Icon(
                  if (featured.inWatchlist) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                  contentDescription = null,
                  tint = CinemaText,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(4.dp))
                Text(if (featured.inWatchlist) "In Watchlist" else "Watchlist", color = CinemaText)
              }
            }
          }
        }
      }
    }

    // Continue Watching Carousel
    val continueWatching = titles.filter { it.progressFraction > 0f }
    if (continueWatching.isNotEmpty()) {
      item {
        CinemaSectionRow(
          sectionTitle = "Continue Watching",
          items = continueWatching,
          showProgress = true,
          onSelect = { selectedMovie = it },
        )
      }
    }

    // Shared Watchlist
    val watchlist = titles.filter { it.inWatchlist }
    if (watchlist.isNotEmpty()) {
      item {
        CinemaSectionRow(
          sectionTitle = "Our Shared Watchlist",
          items = watchlist,
          showProgress = false,
          onSelect = { selectedMovie = it },
        )
      }
    }

    // All Movies & Series Discovery
    item {
      CinemaSectionRow(
        sectionTitle = "Curated Movies & Series",
        items = titles,
        showProgress = false,
        onSelect = { selectedMovie = it },
      )
    }
  }

  // Movie Details Sheet
  selectedMovie?.let { movie ->
    ModalBottomSheet(
      onDismissRequest = { selectedMovie = null },
      containerColor = CinemaSurface,
      contentColor = CinemaText,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(movie.sourceLabel, style = MaterialTheme.typography.labelSmall, color = CinemaAccentPeach)
        Text("${movie.title} (${movie.year})", style = MaterialTheme.typography.headlineSmall, color = CinemaText)
        Text("${movie.genre} • ${movie.duration}", style = MaterialTheme.typography.bodyMedium, color = CinemaAccentLavender)
        Text(movie.synopsis, style = MaterialTheme.typography.bodyLarge, color = CinemaText.copy(alpha = 0.88f))
        Text("Languages: ${movie.languages} • Subtitles: ${movie.subtitles}", style = MaterialTheme.typography.labelMedium, color = CinemaMuted)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          Button(
            onClick = {
              onStartWatchTogether(movie.id)
              selectedMovie = null
              inWatchRoom = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = CinemaAccentPink, contentColor = CinemaBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Rounded.Group, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Watch Together")
          }
          OutlinedButton(
            onClick = { onToggleWatchlist(movie) },
            border = BorderStroke(1.dp, CinemaAccentLavender),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Text(if (movie.inWatchlist) "Saved" else "+ List", color = CinemaText)
          }
        }
        Spacer(Modifier.height(20.dp))
      }
    }
  }
}

@Composable
private fun CinemaSectionRow(
  sectionTitle: String,
  items: List<CinemaTitleEntity>,
  showProgress: Boolean,
  onSelect: (CinemaTitleEntity) -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text(
      text = sectionTitle,
      style = MaterialTheme.typography.titleLarge,
      color = CinemaText,
      modifier = Modifier.padding(horizontal = 18.dp),
    )
    LazyRow(
      contentPadding = PaddingValues(horizontal = 18.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      items(items, key = { it.id }) { movie ->
        val posterGradient =
          when (movie.posterTone % 4) {
            0 -> listOf(Color(0xFF42284E), Color(0xFF1F1830))
            1 -> listOf(Color(0xFF4D2B38), Color(0xFF1E1728))
            2 -> listOf(Color(0xFF283A52), Color(0xFF171929))
            else -> listOf(Color(0xFF3E3156), Color(0xFF191526))
          }
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = CinemaCard,
          modifier = Modifier.width(156.dp).clickable { onSelect(movie) },
        ) {
          Column {
            Box(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .height(118.dp)
                  .background(Brush.linearGradient(posterGradient))
                  .padding(12.dp),
              contentAlignment = Alignment.BottomStart,
            ) {
              Text(movie.category.uppercase(), style = MaterialTheme.typography.labelSmall, color = CinemaAccentPeach)
            }
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(movie.title, style = MaterialTheme.typography.titleMedium, color = CinemaText, maxLines = 1)
              Text("${movie.year} • ${movie.duration}", style = MaterialTheme.typography.labelSmall, color = CinemaMuted)
              if (showProgress) {
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                  progress = { movie.progressFraction },
                  color = CinemaAccentPink,
                  trackColor = Color.White.copy(alpha = 0.16f),
                  modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun WatchTogetherRoomView(
  movie: CinemaTitleEntity?,
  state: WatchTogetherState,
  onTogglePlayPause: () -> Unit,
  onSeek: (Float) -> Unit,
  onReaction: (String) -> Unit,
  onSendChat: (String) -> Unit,
  onLeaveRoom: () -> Unit,
) {
  var draftMsg by remember { mutableStateOf("") }

  Column(
    modifier = Modifier.fillMaxSize().background(CinemaBg).statusBarsPadding().navigationBarsPadding().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onLeaveRoom) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Leave room", tint = CinemaText)
        }
        Column {
          Text(movie?.title ?: "Watch Together", style = MaterialTheme.typography.titleLarge, color = CinemaText)
          Text("Synced Lounge • 2/2 Joined", style = MaterialTheme.typography.labelSmall, color = CinemaAccentPink)
        }
      }
      Surface(shape = CircleShape, color = CinemaCard) {
        Text(
          text = if (state.isPlaying) "Synced Playing" else "Synced Paused",
          style = MaterialTheme.typography.labelSmall,
          color = CinemaAccentPeach,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )
      }
    }

    // Synchronized Cinema Viewport
    Box(
      modifier = Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(24.dp))
    ) {
      Image(
        painter = painterResource(R.drawable.img_cinema_featured_1795279160527),
        contentDescription = "Synchronized theater preview",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
      Box(modifier = Modifier.fillMaxSize().background(CinemaBg.copy(alpha = if (state.isPlaying) 0.25f else 0.55f)))

      // Floating Emoji Reactions Strip
      Row(
        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        state.recentReactions.take(4).forEach { emoji ->
          Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.55f)) {
            Text(emoji, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
          }
        }
      }

      Surface(
        onClick = onTogglePlayPause,
        shape = CircleShape,
        color = CinemaAccentPink,
        modifier = Modifier.align(Alignment.Center).size(62.dp).testTag("watch_together_play_pause"),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            contentDescription = stringResource(R.string.cd_play_pause),
            tint = CinemaBg,
            modifier = Modifier.size(34.dp),
          )
        }
      }
    }

    // Synced Timeline Scrubber
    Column {
      Slider(
        value = state.positionFraction,
        onValueChange = onSeek,
        modifier = Modifier.fillMaxWidth(),
      )
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Synced Position: ${(state.positionFraction * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = CinemaMuted)
        Text("Connect authorized stream URL in Settings", style = MaterialTheme.typography.labelSmall, color = CinemaAccentLavender)
      }
    }

    // Quick Emoji Reaction Bar
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
      listOf("🍿", "💛", "😂", "✨", "🥹", "👏").forEach { emoji ->
        Surface(
          onClick = { onReaction(emoji) },
          shape = CircleShape,
          color = CinemaCard,
          modifier = Modifier.size(44.dp),
        ) {
          Box(contentAlignment = Alignment.Center) { Text(emoji) }
        }
      }
    }

    // Private Watch Party Chat
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = CinemaSurface,
      modifier = Modifier.fillMaxWidth().weight(1f),
    ) {
      Column(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Watch Room Chat", style = MaterialTheme.typography.titleMedium, color = CinemaAccentPink)
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          items(state.roomChat) { (sender, msg) ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Text("$sender:", style = MaterialTheme.typography.labelMedium, color = CinemaAccentPeach)
              Text(msg, style = MaterialTheme.typography.bodyMedium, color = CinemaText)
            }
          }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = draftMsg,
            onValueChange = { draftMsg = it },
            placeholder = { Text("Whisper during the movie...", color = CinemaMuted) },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = CinemaText, unfocusedTextColor = CinemaText),
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          IconButton(
            onClick = {
              if (draftMsg.isNotBlank()) {
                onSendChat(draftMsg)
                draftMsg = ""
              }
            },
            modifier = Modifier.minimumInteractiveComponentSize().clip(CircleShape).background(CinemaAccentPink),
          ) {
            Icon(Icons.Rounded.Send, contentDescription = "Send", tint = CinemaBg)
          }
        }
      }
    }
  }
}
