package com.example.vibely.ui.chat

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Reply
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyLavenderSoft
import com.example.ui.theme.VibelyMint
import com.example.ui.theme.VibelyPeachSoft
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.vibely.data.ChatMessageEntity
import com.example.vibely.data.UserProfileEntity

@Composable
fun PrivateChatScreen(
  messages: List<ChatMessageEntity>,
  profiles: List<UserProfileEntity>,
  activeUserSlot: String,
  onSwitchAccount: () -> Unit,
  onSendMessage: (text: String, attachType: String?, attachLabel: String?, reply: String?) -> Unit,
  onReact: (ChatMessageEntity, String) -> Unit,
  onDelete: (Int) -> Unit,
  onBack: () -> Unit,
) {
  var draft by remember { mutableStateOf("") }
  var showSearch by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }
  var replyTo by remember { mutableStateOf<ChatMessageEntity?>(null) }
  var selectedMessageForActions by remember { mutableStateOf<ChatMessageEntity?>(null) }

  val me = profiles.firstOrNull { it.slot == activeUserSlot }
  val partner = profiles.firstOrNull { it.slot != activeUserSlot }

  val visibleMessages =
    remember(messages, searchQuery) {
      if (searchQuery.isBlank()) messages
      else messages.filter { it.text.contains(searchQuery, true) || (it.attachmentLabel?.contains(searchQuery, true) == true) }
    }

  Column(
    modifier = Modifier.fillMaxSize().background(VibelyCream).statusBarsPadding().navigationBarsPadding().imePadding(),
  ) {
    // Top Header
    Surface(color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize().testTag("chat_back_button")) {
              Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = VibelyInk)
            }
            Column {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(partner?.displayName ?: "Partner", style = MaterialTheme.typography.titleLarge, color = VibelyInk)
                Icon(Icons.Rounded.Lock, contentDescription = "Private", tint = VibelyMint, modifier = Modifier.size(15.dp))
              }
              Text("Sending as ${me?.displayName ?: activeUserSlot} • Private 1:1", style = MaterialTheme.typography.labelSmall, color = VibelyPink)
            }
          }

          Row {
            IconButton(onClick = { showSearch = !showSearch }, modifier = Modifier.minimumInteractiveComponentSize()) {
              Icon(Icons.Rounded.Search, contentDescription = "Search chat", tint = VibelyInk)
            }
            IconButton(onClick = onSwitchAccount, modifier = Modifier.minimumInteractiveComponentSize().testTag("chat_switch_sender")) {
              Icon(Icons.Rounded.SwapHoriz, contentDescription = stringResource(R.string.cd_switch_account), tint = VibelyPink)
            }
          }
        }

        if (showSearch) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search messages...") },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
          )
        }
      }
    }

    // Message List
    LazyColumn(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      items(visibleMessages, key = { it.id }) { msg ->
        val isMine = msg.senderSlot == activeUserSlot
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = if (isMine) Alignment.End else Alignment.Start,
        ) {
          Surface(
            shape =
              RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isMine) 20.dp else 6.dp,
                bottomEnd = if (isMine) 6.dp else 20.dp,
              ),
            color = if (isMine) VibelyPinkSoft else Color.White,
            border = BorderStroke(1.dp, if (isMine) VibelyPink.copy(alpha = 0.25f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
            modifier =
              Modifier
                .widthIn(max = 290.dp)
                .clickable {
                  selectedMessageForActions = if (selectedMessageForActions?.id == msg.id) null else msg
                }
                .testTag("chat_msg_${msg.id}"),
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
              msg.replyPreview?.let { reply ->
                Surface(shape = RoundedCornerShape(10.dp), color = Color.White.copy(alpha = 0.65f)) {
                  Text(
                    text = "Replying: $reply",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  )
                }
              }

              msg.attachmentLabel?.let { label ->
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = if (msg.attachmentType == "music") VibelyLavenderSoft else VibelyPeachSoft,
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                  ) {
                    if (msg.attachmentType == "music") {
                      Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = VibelyInk, modifier = Modifier.size(16.dp))
                    } else if (msg.attachmentType == "movie") {
                      Icon(Icons.Rounded.Movie, contentDescription = null, tint = VibelyInk, modifier = Modifier.size(16.dp))
                    }
                    Text(label, style = MaterialTheme.typography.labelMedium, color = VibelyInk)
                  }
                }
              }

              if (msg.text.isNotBlank()) {
                Text(msg.text, style = MaterialTheme.typography.bodyLarge, color = VibelyInk)
              }

              msg.reactionEmoji?.let { emoji ->
                Surface(shape = CircleShape, color = Color.White, shadowElevation = 1.dp) {
                  Text(emoji, modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp))
                }
              }
            }
          }

          // Quick Message Action Strip (React / Reply / Delete)
          if (selectedMessageForActions?.id == msg.id) {
            Row(
              modifier = Modifier.padding(top = 4.dp),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              listOf("💛", "✨", "🐼", "😂").forEach { emoji ->
                Surface(
                  onClick = {
                    onReact(msg, emoji)
                    selectedMessageForActions = null
                  },
                  shape = CircleShape,
                  color = Color.White,
                  shadowElevation = 2.dp,
                ) {
                  Text(emoji, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
              }
              Surface(
                onClick = {
                  replyTo = msg
                  selectedMessageForActions = null
                },
                shape = CircleShape,
                color = Color.White,
              ) {
                Icon(Icons.Rounded.Reply, contentDescription = "Reply", tint = VibelyInk, modifier = Modifier.padding(6.dp).size(16.dp))
              }
              Surface(
                onClick = {
                  onDelete(msg.id)
                  selectedMessageForActions = null
                },
                shape = CircleShape,
                color = Color.White,
              ) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete", tint = VibelyPink, modifier = Modifier.padding(6.dp).size(16.dp))
              }
            }
          }
        }
      }
    }

    // Quick Share Chips (Stickers, Song, Movie)
    LazyRow(
      contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      item {
        ChatQuickChip("🐼 Panda Hug") { onSendMessage("", "sticker", "🐼 Mochi sends a cozy hug!", replyTo?.text); replyTo = null }
      }
      item {
        ChatQuickChip("🎵 Share Song") { onSendMessage("Listen to this with me!", "music", "Peach Cloud Lullaby", replyTo?.text); replyTo = null }
      }
      item {
        ChatQuickChip("🎬 Movie Invite") { onSendMessage("Join Watch Together?", "movie", "Charade (1963)", replyTo?.text); replyTo = null }
      }
    }

    // Reply Banner
    replyTo?.let { target ->
      Surface(color = VibelyLavenderSoft, modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Replying to: ${target.text.ifBlank { target.attachmentLabel ?: "" }}", style = MaterialTheme.typography.labelMedium, maxLines = 1, modifier = Modifier.weight(1f))
          IconButton(onClick = { replyTo = null }, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Rounded.Close, contentDescription = "Cancel reply", modifier = Modifier.size(16.dp))
          }
        }
      }
    }

    // Input Composer
    Surface(color = Color.White, shadowElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = draft,
          onValueChange = { draft = it },
          placeholder = { Text("Message ${partner?.displayName ?: "partner"}...") },
          shape = RoundedCornerShape(24.dp),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("chat_message_input"),
        )
        IconButton(
          onClick = {
            if (draft.isNotBlank()) {
              onSendMessage(draft, null, null, replyTo?.text)
              draft = ""
              replyTo = null
            }
          },
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clip(CircleShape)
              .background(VibelyPink)
              .testTag("chat_send_button"),
        ) {
          Icon(Icons.Rounded.Send, contentDescription = stringResource(R.string.cd_send_message), tint = Color.White)
        }
      }
    }
  }
}

@Composable
private fun ChatQuickChip(label: String, onClick: () -> Unit) {
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = Color.White,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
  ) {
    Text(label, style = MaterialTheme.typography.labelMedium, color = VibelyInk, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
  }
}
