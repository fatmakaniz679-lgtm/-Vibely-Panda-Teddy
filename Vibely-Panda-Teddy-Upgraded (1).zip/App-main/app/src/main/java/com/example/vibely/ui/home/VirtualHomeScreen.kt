package com.example.vibely.ui.home

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.animateFloatAsState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Park
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Weekend
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyGold
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyLavender
import com.example.ui.theme.VibelyLavenderSoft
import com.example.ui.theme.VibelyMint
import com.example.ui.theme.VibelyPeach
import com.example.ui.theme.VibelyPeachSoft
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.vibely.data.RoomFurnitureEntity
import com.example.vibely.data.RoomStateEntity
import com.example.vibely.data.UserProfileEntity
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

private data class HomeSideMenuItem(
  val id: String,
  val label: String,
  val icon: ImageVector,
  val tint: Color,
  val onClick: () -> Unit,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualHomeScreen(
  roomState: RoomStateEntity,
  furniture: List<RoomFurnitureEntity>,
  profiles: List<UserProfileEntity>,
  unreadChatCount: Int,
  onSwitchAccount: () -> Unit,
  onTogglePrivacy: () -> Unit,
  onUpdateRoomName: (String) -> Unit,
  onSetWallpaper: (String) -> Unit,
  onSetLighting: (String) -> Unit,
  onCyclePandaMood: () -> Unit,
  onCycleTeddyMood: () -> Unit,
  onMoveFurniture: (RoomFurnitureEntity, Float, Float) -> Unit,
  onToggleFurniturePlaced: (RoomFurnitureEntity) -> Unit,
  onSetFramePhoto: (String) -> Unit,
  onOpenChat: () -> Unit,
  onOpenMemories: () -> Unit,
  onOpenMusic: () -> Unit,
  onOpenSnapshots: () -> Unit,
  onOpenCinema: () -> Unit,
  onOpenPlayTogether: () -> Unit,
  onOpenTimeCapsule: () -> Unit,
  bottomContentPadding: PaddingValues,
) {
  var showShopSheet by remember { mutableStateOf(false) }
  var showSettingsSheet by remember { mutableStateOf(false) }
  var showNotificationsSheet by remember { mutableStateOf(false) }
  var activeBubbleText by remember { mutableStateOf<String?>(null) }

  // Pet progress is stored locally so levels survive app restarts without changing Room schema.
  val appContext = LocalContext.current
  val petPrefs = remember { appContext.getSharedPreferences("vibely_pet_progress", Context.MODE_PRIVATE) }
  var petXp by remember { mutableIntStateOf(petPrefs.getInt("xp", 0)) }
  var activePetAction by remember { mutableStateOf("idle") }
  var kissTrigger by remember { mutableIntStateOf(0) }
  var showKissExplosion by remember { mutableStateOf(false) }
  val petSound = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 68) }
  DisposableEffect(Unit) {
    onDispose { petSound.release() }
  }
  LaunchedEffect(kissTrigger) {
    if (kissTrigger > 0) {
      showKissExplosion = true
      delay(1750)
      showKissExplosion = false
    }
  }
  // Most pet actions play as a short pose sequence and then settle back to idle.
  // Sleeping is intentionally persistent until Wake up is selected.
  LaunchedEffect(activePetAction) {
    val runningAction = activePetAction
    if (runningAction != "idle" && runningAction != "sleep") {
      delay(1950)
      if (activePetAction == runningAction) activePetAction = "idle"
    }
  }
  val performPetAction: (String) -> Unit = { action ->
    activePetAction = action
    petXp += if (action == "grow") 10 else 2
    petPrefs.edit().putInt("xp", petXp).apply()
    val tone = when (action) {
      "eat" -> ToneGenerator.TONE_DTMF_1
      "drink" -> ToneGenerator.TONE_DTMF_2
      "bath" -> ToneGenerator.TONE_DTMF_3
      "sleep" -> ToneGenerator.TONE_DTMF_4
      "wake" -> ToneGenerator.TONE_DTMF_5
      "walk" -> ToneGenerator.TONE_DTMF_6
      "dance" -> ToneGenerator.TONE_DTMF_7
      "laugh" -> ToneGenerator.TONE_DTMF_8
      "cry" -> ToneGenerator.TONE_DTMF_9
      "fart" -> ToneGenerator.TONE_PROP_NACK
      "play" -> ToneGenerator.TONE_PROP_ACK
      "grow" -> ToneGenerator.TONE_PROP_PROMPT
      "kiss" -> ToneGenerator.TONE_PROP_BEEP2
      else -> ToneGenerator.TONE_PROP_BEEP
    }
    petSound.startTone(tone, 180)
    activeBubbleText = when (action) {
      "eat" -> "Mochi and Boba are munching bamboo!"
      "drink" -> "A refreshing drink break!"
      "bath" -> "Bubble bath time!"
      "sleep" -> "Sweet dreams, little ones."
      "wake" -> "Good morning! Stretch and shine!"
      "walk" -> "Let's go for a little walk!"
      "dance" -> "Dance party in the pet room!"
      "laugh" -> "That was a good one!"
      "cry" -> "A little comfort, please."
      "fart" -> "Poot! Someone made a silly noise!"
      "play" -> "Playtime together!"
      "grow" -> "Your pets earned growth XP!"
      "kiss" -> "A shower of love for Mochi and Boba!"
      else -> "Your pets are feeling cozy."
    }
    if (action == "kiss") kissTrigger++
  }

  val photoPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        onSetFramePhoto(uri.toString())
        activeBubbleText = "Photo added to wall frame!"
      }
    }

  val userA = profiles.firstOrNull { it.slot == "A" }
  val userB = profiles.firstOrNull { it.slot == "B" }

  val infiniteTransition = rememberInfiniteTransition(label = "room_ambient")
  val characterBob by
    infiniteTransition.animateFloat(
      initialValue = -4f,
      targetValue = 4f,
      animationSpec = infiniteRepeatable(tween(1900), RepeatMode.Reverse),
      label = "bob",
    )
  val lampPulse by
    infiniteTransition.animateFloat(
      initialValue = 0.25f,
      targetValue = 0.48f,
      animationSpec = infiniteRepeatable(tween(2400), RepeatMode.Reverse),
      label = "lamp_pulse",
    )

  val wallpaperOverlay =
    when (roomState.wallpaperTheme) {
      "Sunset Peach" -> VibelyPeach.copy(alpha = 0.16f)
      "Dreamy Lavender" -> VibelyLavender.copy(alpha = 0.18f)
      "Starry Night" -> Color(0xFF1A1633).copy(alpha = 0.36f)
      else -> Color.Transparent
    }

  val lightingOverlay =
    when (roomState.lightingMode) {
      "Cozy Lamp" -> Color(0xFFFFB76B).copy(alpha = 0.16f)
      "Twilight" -> Color(0xFF281E4A).copy(alpha = 0.28f)
      "Daylight" -> Color(0xFFFFFFFF).copy(alpha = 0.08f)
      else -> Color(0xFFFFDFB8).copy(alpha = 0.10f)
    }

  val sideMenu =
    listOf(
      HomeSideMenuItem("memories", stringResource(R.string.menu_memories), Icons.Rounded.PhotoLibrary, VibelyPink, onOpenMemories),
      HomeSideMenuItem("music", stringResource(R.string.menu_music), Icons.Rounded.MusicNote, VibelyLavender, onOpenMusic),
      HomeSideMenuItem("snapshots", stringResource(R.string.menu_snapshots), Icons.Rounded.CameraAlt, VibelyPeach, onOpenSnapshots),
      HomeSideMenuItem("cinema", stringResource(R.string.menu_cinema), Icons.Rounded.Movie, Color(0xFF6A5ACD), onOpenCinema),
      HomeSideMenuItem("play", stringResource(R.string.menu_play), Icons.Rounded.Extension, VibelyMint, onOpenPlayTogether),
      HomeSideMenuItem("capsule", stringResource(R.string.menu_capsule), Icons.Rounded.HourglassBottom, VibelyGold, onOpenTimeCapsule),
      HomeSideMenuItem("shop", stringResource(R.string.menu_shop), Icons.Rounded.Storefront, VibelyPink) { showShopSheet = true },
    )

  Box(modifier = Modifier.fillMaxSize().background(VibelyCream)) {
    // 1. Illustrated Virtual Home Room Background
    Image(
      painter = painterResource(id = R.drawable.img_virtual_room_bg_1795279159875),
      contentDescription = stringResource(R.string.cd_virtual_room),
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )

    // Dynamic wallpaper & lighting mood layers
    Box(modifier = Modifier.fillMaxSize().background(wallpaperOverlay))
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(lightingOverlay, Color.Transparent, lightingOverlay.copy(alpha = 0.22f))
            )
          )
    )

    // 2. Interactive Draggable Furniture + Animated Characters Layer
    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(bottom = bottomContentPadding.calculateBottomPadding())
    ) {
      val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
      val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
      val density = LocalDensity.current

      furniture.filter { it.isPlaced }.forEach { item ->
        var dragX by remember(item.id, item.xFraction) { mutableFloatStateOf(item.xFraction) }
        var dragY by remember(item.id, item.yFraction) { mutableFloatStateOf(item.yFraction) }

        val offsetX = (dragX * widthPx).roundToInt() - with(density) { 42.dp.roundToPx() }
        val offsetY = (dragY * heightPx).roundToInt() - with(density) { 42.dp.roundToPx() }

        Box(
          modifier =
            Modifier
              .offset { IntOffset(offsetX, offsetY) }
              .pointerInput(item.id) {
                detectDragGestures(
                  onDragEnd = { onMoveFurniture(item, dragX, dragY) },
                  onDrag = { change, dragAmount ->
                    change.consume()
                    dragX = (dragX + dragAmount.x / widthPx).coerceIn(0.08f, 0.80f)
                    dragY = (dragY + dragAmount.y / heightPx).coerceIn(0.22f, 0.82f)
                  },
                )
              }
              .clickable {
                if (item.id == "frame") {
                  photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                } else {
                  activeBubbleText = "${item.name} • Drag anywhere to move!"
                }
              }
              .testTag("room_furniture_${item.id}")
        ) {
          VirtualFurniturePiece(item = item, lampPulse = lampPulse)
        }
      }

      // Interactive Animated Panda Character (left-center on cozy rug)
      Box(
        modifier =
          Modifier
            .offset {
              IntOffset(
                (0.28f * widthPx).roundToInt(),
                (0.67f * heightPx + characterBob).roundToInt(),
              )
            }
            .clickable {
              onCyclePandaMood()
              activeBubbleText = "Mochi Panda feels ${roomState.pandaMood}!"
            }
            .testTag("panda_character")
      ) {
        CuteCharacterCard(
          name = "Mochi",
          mood = roomState.pandaMood,
          action = activePetAction,
          level = petXp / 20 + 1,
          isPanda = true,
        )
      }

      // Interactive Animated Teddy Character (right-center on cozy rug)
      Box(
        modifier =
          Modifier
            .offset {
              IntOffset(
                (0.50f * widthPx).roundToInt(),
                (0.68f * heightPx - characterBob).roundToInt(),
              )
            }
            .clickable {
              onCycleTeddyMood()
              activeBubbleText = "Boba Teddy feels ${roomState.teddyMood}!"
            }
            .testTag("teddy_character")
      ) {
        CuteCharacterCard(
          name = "Boba",
          mood = roomState.teddyMood,
          action = activePetAction,
          level = petXp / 20 + 1,
          isPanda = false,
        )
      }
    }

    // Interactive pet activity tray. Every chip dispatches a real pet state change.
    PetActionTray(
      selectedAction = activePetAction,
      level = petXp / 20 + 1,
      xp = petXp % 20,
      onAction = performPetAction,
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .padding(horizontal = 10.dp)
        .padding(bottom = bottomContentPadding.calculateBottomPadding() + 10.dp),
    )

    // Full-screen animated heart burst for the shared kiss interaction.
    if (showKissExplosion) {
      val heartFloat by rememberInfiniteTransition(label = "kiss_heart_float").animateFloat(
        initialValue = 22f,
        targetValue = -72f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "heart_float",
      )
      Box(modifier = Modifier.fillMaxSize().background(Color(0x26FF5C9A))) {
        repeat(15) { index ->
          Text(
            text = when (index % 4) { 0 -> "❤️"; 1 -> "💗"; 2 -> "💖"; else -> "💕" },
            modifier = Modifier
              .align(Alignment.Center)
              .offset(
                x = ((index % 5) - 2) * 54.dp,
                y = ((index / 5) - 1) * 50.dp + heartFloat.dp,
              ),
            style = MaterialTheme.typography.headlineLarge,
          )
        }
        Surface(
          modifier = Modifier.align(Alignment.Center).padding(top = 150.dp),
          shape = RoundedCornerShape(24.dp),
          color = Color.White.copy(alpha = 0.94f),
          shadowElevation = 12.dp,
        ) {
          Text(
            "Mochi & Boba share the love!",
            color = Color(0xFFB52B67),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
          )
        }
      }
    }

    // 3. Top Frosted Header Bar (Two User Avatars, Room Name, Online Status, Chat, Notifications, Settings)
    Column(
      modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Surface(
        shape = RoundedCornerShape(26.dp),
        color = Color.White.copy(alpha = 0.88f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f)),
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          // Two Authorized User Avatars + Room Name + Online Pill
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier =
              Modifier
                .weight(1f)
                .clip(RoundedCornerShape(18.dp))
                .clickable(onClick = onSwitchAccount)
                .padding(vertical = 2.dp)
                .testTag("home_account_switcher"),
          ) {
            Box(modifier = Modifier.width(56.dp).height(38.dp)) {
              UserMiniAvatar(
                initial = userA?.displayName?.firstOrNull()?.toString() ?: "A",
                tint = VibelyPinkSoft,
                isActive = roomState.activeUserSlot == "A",
                modifier = Modifier.align(Alignment.CenterStart),
              )
              UserMiniAvatar(
                initial = userB?.displayName?.firstOrNull()?.toString() ?: "Z",
                tint = VibelyLavenderSoft,
                isActive = roomState.activeUserSlot == "B",
                modifier = Modifier.align(Alignment.CenterEnd),
              )
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = roomState.roomName,
                style = MaterialTheme.typography.titleMedium,
                color = VibelyInk,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
              ) {
                Box(
                  modifier =
                    Modifier
                      .size(7.dp)
                      .background(
                        if (roomState.showOnlineStatus) VibelyMint else VibelyPeach,
                        CircleShape,
                      )
                )
                Text(
                  text =
                    if (roomState.showOnlineStatus) {
                      "${if (roomState.activeUserSlot == "A") userA?.displayName ?: "Aria" else userB?.displayName ?: "Zayn"} • ${stringResource(R.string.home_online)}"
                    } else {
                      stringResource(R.string.home_private_status)
                    },
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }

          // Top-Right Action Icons: Private Chat, Notifications, Settings
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box {
              IconButton(
                onClick = onOpenChat,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("top_chat_button"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.ChatBubbleOutline,
                  contentDescription = stringResource(R.string.cd_open_chat),
                  tint = VibelyPink,
                )
              }
              if (unreadChatCount > 0) {
                Box(
                  modifier =
                    Modifier
                      .align(Alignment.TopEnd)
                      .padding(top = 9.dp, end = 9.dp)
                      .size(9.dp)
                      .background(VibelyPink, CircleShape)
                      .border(1.5.dp, Color.White, CircleShape)
                )
              }
            }

            IconButton(
              onClick = { showNotificationsSheet = true },
              modifier = Modifier.size(40.dp).testTag("top_notifications_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.Notifications,
                contentDescription = stringResource(R.string.cd_notifications),
                tint = VibelyInk,
                modifier = Modifier.size(21.dp),
              )
            }

            IconButton(
              onClick = { showSettingsSheet = true },
              modifier = Modifier.size(40.dp).testTag("top_settings_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.Settings,
                contentDescription = stringResource(R.string.cd_settings),
                tint = VibelyInk,
                modifier = Modifier.size(21.dp),
              )
            }
          }
        }
      }

      // Interactive Toast / Room Hint Pill
      AnimatedVisibility(
        visible = activeBubbleText != null,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = Modifier.align(Alignment.CenterHorizontally),
      ) {
        Surface(
          shape = CircleShape,
          color = VibelyInk.copy(alpha = 0.80f),
          onClick = { activeBubbleText = null },
        ) {
          Text(
            text = activeBubbleText ?: "",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
          )
        }
      }
    }

    // 4. Right-Side Interactive Glassmorphic Menu (All 7 Features)
    Column(
      modifier =
        Modifier
          .align(Alignment.CenterEnd)
          .padding(end = 10.dp, top = 56.dp, bottom = bottomContentPadding.calculateBottomPadding() + 24.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      sideMenu.forEach { item ->
        Surface(
          onClick = item.onClick,
          shape = RoundedCornerShape(18.dp),
          color = Color.White.copy(alpha = 0.86f),
          border = BorderStroke(1.dp, Color.White),
          shadowElevation = 4.dp,
          modifier = Modifier.width(62.dp).testTag("home_menu_${item.id}"),
        ) {
          Column(
            modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
          ) {
            Box(
              modifier =
                Modifier
                  .size(28.dp)
                  .background(item.tint.copy(alpha = 0.16f), CircleShape),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = item.icon,
                contentDescription = item.label,
                tint = item.tint,
                modifier = Modifier.size(16.dp),
              )
            }
            Text(
              text = item.label,
              style = MaterialTheme.typography.labelSmall,
              color = VibelyInk,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }

    // 5. Bottom Hint Pill above Navigation Bar
    Surface(
      shape = CircleShape,
      color = Color.White.copy(alpha = 0.82f),
      border = BorderStroke(1.dp, Color.White),
      modifier =
        Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = bottomContentPadding.calculateBottomPadding() + 14.dp)
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Rounded.AutoAwesome,
          contentDescription = null,
          tint = VibelyPink,
          modifier = Modifier.size(14.dp),
        )
        Text(
          text = stringResource(R.string.home_drag_hint),
          style = MaterialTheme.typography.labelSmall,
          color = VibelyInk,
        )
      }
    }
  }

  // Room Shop & Customization Bottom Sheet
  if (showShopSheet) {
    ModalBottomSheet(
      onDismissRequest = { showShopSheet = false },
      containerColor = VibelyCream,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        Text("Room Shop & Customizer", style = MaterialTheme.typography.headlineSmall, color = VibelyInk)

        Text("Wallpapers", style = MaterialTheme.typography.titleMedium, color = VibelyInk)
        val wallpapers = listOf("Blush Cream", "Sunset Peach", "Dreamy Lavender", "Starry Night")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(wallpapers) { wp ->
            FilterChip(
              selected = roomState.wallpaperTheme == wp,
              onClick = { onSetWallpaper(wp) },
              label = { Text(wp) },
              modifier = Modifier.testTag("wallpaper_$wp"),
            )
          }
        }

        Text("Lighting Mood", style = MaterialTheme.typography.titleMedium, color = VibelyInk)
        val lights = listOf("Warm Glow", "Daylight", "Cozy Lamp", "Twilight")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(lights) { mode ->
            FilterChip(
              selected = roomState.lightingMode == mode,
              onClick = { onSetLighting(mode) },
              label = { Text(mode) },
              modifier = Modifier.testTag("lighting_$mode"),
            )
          }
        }

        Text("Furniture & Decor (Place or Store)", style = MaterialTheme.typography.titleMedium, color = VibelyInk)
        furniture.forEach { item ->
          Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column {
                Text(item.name, style = MaterialTheme.typography.titleMedium, color = VibelyInk)
                Text(item.category, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Switch(
                checked = item.isPlaced,
                onCheckedChange = { onToggleFurniturePlaced(item) },
                modifier = Modifier.testTag("toggle_furniture_${item.id}"),
              )
            }
          }
        }

        Button(
          onClick = {
            photoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
            showShopSheet = false
          },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        ) {
          Icon(Icons.Rounded.Photo, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text("Pick Wall Frame Photo")
        }

        Spacer(Modifier.height(24.dp))
      }
    }
  }

  // Room Settings Sheet
  if (showSettingsSheet) {
    var draftName by remember(roomState.roomName) { mutableStateOf(roomState.roomName) }
    ModalBottomSheet(
      onDismissRequest = { showSettingsSheet = false },
      containerColor = VibelyCream,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Text("Virtual Room Settings", style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
        OutlinedTextField(
          value = draftName,
          onValueChange = { draftName = it },
          label = { Text("Room Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("Show Online Status", style = MaterialTheme.typography.titleMedium)
            Text(
              "Let your partner see when you're hanging out in the room",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Switch(checked = roomState.showOnlineStatus, onCheckedChange = { onTogglePrivacy() })
        }
        Button(
          onClick = {
            onUpdateRoomName(draftName)
            showSettingsSheet = false
          },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        ) {
          Text("Save Room Settings")
        }
        Spacer(Modifier.height(24.dp))
      }
    }
  }

  // Notifications Sheet
  if (showNotificationsSheet) {
    ModalBottomSheet(
      onDismissRequest = { showNotificationsSheet = false },
      containerColor = VibelyCream,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text("Universe Activity", style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
        NotificationRow("Zayn added 'Midnight Rooftop Tape' to Our Playlist", "12m ago")
        NotificationRow("Two Minds daily question is waiting for an answer", "1h ago")
        NotificationRow("Time Capsule 'Open on Our Anniversary' is safely sealed", "Yesterday")
        Spacer(Modifier.height(24.dp))
      }
    }
  }
}

@Composable
private fun NotificationRow(text: String, time: String) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = Color.White,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(text, style = MaterialTheme.typography.bodyMedium, color = VibelyInk, modifier = Modifier.weight(1f))
      Spacer(Modifier.width(8.dp))
      Text(time, style = MaterialTheme.typography.labelSmall, color = VibelyPink)
    }
  }
}

@Composable
private fun UserMiniAvatar(
  initial: String,
  tint: Color,
  isActive: Boolean,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .size(34.dp)
        .shadow(if (isActive) 4.dp else 1.dp, CircleShape)
        .background(tint, CircleShape)
        .border(
          width = if (isActive) 2.5.dp else 1.5.dp,
          color = if (isActive) VibelyPink else Color.White,
          shape = CircleShape,
        ),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = initial,
      style = MaterialTheme.typography.labelLarge,
      fontWeight = FontWeight.Bold,
      color = VibelyInk,
    )
  }
}

@Composable
private fun VirtualFurniturePiece(
  item: RoomFurnitureEntity,
  lampPulse: Float,
) {
  when (item.iconKey) {
    "sofa" -> {
      Surface(
        shape = RoundedCornerShape(22.dp),
        color = VibelyPinkSoft.copy(alpha = 0.96f),
        border = BorderStroke(2.dp, Color.White),
        shadowElevation = 6.dp,
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(Icons.Rounded.Weekend, contentDescription = item.name, tint = VibelyPink, modifier = Modifier.size(30.dp))
          Column {
            Text("Cloud Sofa", style = MaterialTheme.typography.labelMedium, color = VibelyInk, fontWeight = FontWeight.Bold)
            Text("Drag me", style = MaterialTheme.typography.labelSmall, color = VibelyPink)
          }
        }
      }
    }
    "lamp" -> {
      Box(contentAlignment = Alignment.Center) {
        Box(
          modifier =
            Modifier
              .size(84.dp)
              .background(
                Brush.radialGradient(
                  listOf(Color(0xFFFFD27D).copy(alpha = lampPulse), Color.Transparent)
                ),
                CircleShape,
              )
        )
        Surface(
          shape = CircleShape,
          color = VibelyPeachSoft,
          border = BorderStroke(2.dp, Color.White),
          shadowElevation = 4.dp,
          modifier = Modifier.size(54.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Lightbulb, contentDescription = item.name, tint = Color(0xFFD98B2B), modifier = Modifier.size(26.dp))
          }
        }
      }
    }
    "plant" -> {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFFE7F8EE),
        border = BorderStroke(2.dp, Color.White),
        shadowElevation = 4.dp,
        modifier = Modifier.size(58.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Rounded.Park, contentDescription = item.name, tint = VibelyMint, modifier = Modifier.size(28.dp))
        }
      }
    }
    "frame" -> {
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(2.5.dp, VibelyPeach),
        shadowElevation = 5.dp,
        modifier = Modifier.size(width = 68.dp, height = 78.dp),
      ) {
        if (item.customPhotoUri != null) {
          AsyncImage(
            model = item.customPhotoUri,
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().padding(4.dp).clip(RoundedCornerShape(10.dp)),
          )
        } else {
          Column(
            modifier = Modifier.fillMaxSize().padding(6.dp).background(VibelyLavenderSoft, RoundedCornerShape(8.dp)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
          ) {
            Icon(Icons.Rounded.Favorite, contentDescription = item.name, tint = VibelyPink, modifier = Modifier.size(20.dp))
            Text("Tap Photo", style = MaterialTheme.typography.labelSmall, color = VibelyInk)
          }
        }
      }
    }
    else -> {
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color(item.accentColorHex),
        border = BorderStroke(1.5.dp, Color.White),
        shadowElevation = 4.dp,
      ) {
        Text(
          text = item.name,
          style = MaterialTheme.typography.labelSmall,
          color = VibelyInk,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
        )
      }
    }
  }
}

@Composable
private fun CuteCharacterCard(
  name: String,
  mood: String,
  action: String,
  level: Int,
  isPanda: Boolean,
) {
  val motionScale by animateFloatAsState(
    targetValue = when (action) {
      "eat", "drink", "laugh" -> 1.08f
      "bath", "play", "grow", "kiss" -> 1.13f
      "sleep" -> 0.94f
      "cry" -> 0.97f
      else -> 1f
    },
    animationSpec = tween(380),
    label = "pet_scale_${name}",
  )
  val motionTilt by animateFloatAsState(
    targetValue = when (action) {
      "dance" -> 10f
      "walk" -> -6f
      "fart" -> 8f
      "wake" -> -4f
      else -> 0f
    },
    animationSpec = tween(300),
    label = "pet_tilt_${name}",
  )
  val bobTransition = rememberInfiniteTransition(label = "pet_bob_${name}")
  val bob by bobTransition.animateFloat(
    initialValue = -3f,
    targetValue = 3f,
    animationSpec = infiniteRepeatable(tween(if (action == "sleep") 1250 else 460), RepeatMode.Reverse),
    label = "pet_bob_value_${name}",
  )
  val selectedRotation = if (action == "dance" || action == "walk") bob * 2.5f else motionTilt
  val growthScale = 1f + (level - 1).coerceAtMost(12) * 0.018f

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Surface(
      shape = CircleShape,
      color = Color.White.copy(alpha = 0.94f),
      shadowElevation = 3.dp,
    ) {
      Text(
        text = "$name  •  Lv.$level  •  $mood",
        style = MaterialTheme.typography.labelMedium,
        color = VibelyInk,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
      )
    }
    Image(
      painter = painterResource(id = petCharacterDrawable(isPanda, action)),
      contentDescription = "$name, $mood, level $level, ${petActionLabel(action)}",
      contentScale = ContentScale.Fit,
      modifier = Modifier
        .size(112.dp)
        .graphicsLayer {
          scaleX = motionScale * growthScale
          scaleY = motionScale * growthScale
          rotationZ = selectedRotation
          translationY = bob * 1.7f
        },
    )
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = Color.White.copy(alpha = 0.88f),
    ) {
      Text(
        text = petActionLabel(action),
        style = MaterialTheme.typography.labelSmall,
        color = VibelyInk,
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
      )
    }
  }
}

@Composable
private fun PetActionTray(
  selectedAction: String,
  level: Int,
  xp: Int,
  onAction: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(22.dp),
    color = Color.White.copy(alpha = 0.95f),
    border = BorderStroke(1.dp, Color.White),
    shadowElevation = 10.dp,
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Text("PET CARE  •  LEVEL $level", style = MaterialTheme.typography.labelMedium, color = VibelyInk, fontWeight = FontWeight.ExtraBold)
        Text("$xp / 20 XP", style = MaterialTheme.typography.labelSmall, color = VibelyPink, fontWeight = FontWeight.Bold)
      }
      Box(modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(VibelyPinkSoft)) {
        Box(modifier = Modifier.fillMaxWidth(xp / 20f).height(5.dp).clip(CircleShape).background(VibelyPink))
      }
      LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(horizontal = 1.dp)) {
        items(PET_ACTIONS, key = { it.id }) { item ->
          FilterChip(
            selected = selectedAction == item.id,
            onClick = { onAction(item.id) },
            label = { Text(item.label, maxLines = 1) },
            modifier = Modifier.testTag("pet_action_${item.id}"),
          )
        }
      }
    }
  }
}

private data class PetActionItem(val id: String, val label: String)

private val PET_ACTIONS = listOf(
  PetActionItem("eat", "Eat bamboo"),
  PetActionItem("drink", "Drink"),
  PetActionItem("bath", "Bath"),
  PetActionItem("sleep", "Sleep"),
  PetActionItem("wake", "Wake up"),
  PetActionItem("walk", "Walk"),
  PetActionItem("dance", "Dance"),
  PetActionItem("laugh", "Laugh"),
  PetActionItem("cry", "Cry"),
  PetActionItem("fart", "Fart"),
  PetActionItem("play", "Play"),
  PetActionItem("grow", "Grow"),
  PetActionItem("kiss", "Kiss"),
)

private fun petActionLabel(action: String): String = when (action) {
  "eat" -> "Eating bamboo"
  "drink" -> "Drinking"
  "bath" -> "Bath time"
  "sleep" -> "Sleeping"
  "wake" -> "Waking up"
  "walk" -> "Walking"
  "dance" -> "Dancing"
  "laugh" -> "Laughing"
  "cry" -> "Needs a hug"
  "fart" -> "Silly toot!"
  "play" -> "Playing"
  "grow" -> "Growing up!"
  "kiss" -> "Love & kisses"
  else -> "Being cozy"
}

private fun petCharacterDrawable(isPanda: Boolean, action: String): Int {
  val panda = isPanda
  return when (action) {
    "eat" -> if (panda) R.drawable.pet_panda_eat else R.drawable.pet_teddy_eat
    "drink" -> if (panda) R.drawable.pet_panda_drink else R.drawable.pet_teddy_drink
    "bath" -> if (panda) R.drawable.pet_panda_bath else R.drawable.pet_teddy_bath
    "sleep" -> if (panda) R.drawable.pet_panda_sleep else R.drawable.pet_teddy_sleep
    "wake" -> if (panda) R.drawable.pet_panda_wake else R.drawable.pet_teddy_wake
    "walk" -> if (panda) R.drawable.pet_panda_walk else R.drawable.pet_teddy_walk
    "dance" -> if (panda) R.drawable.pet_panda_dance else R.drawable.pet_teddy_dance
    "laugh" -> if (panda) R.drawable.pet_panda_laugh else R.drawable.pet_teddy_laugh
    "cry" -> if (panda) R.drawable.pet_panda_cry else R.drawable.pet_teddy_cry
    "fart" -> if (panda) R.drawable.pet_panda_fart else R.drawable.pet_teddy_fart
    "play" -> if (panda) R.drawable.pet_panda_play else R.drawable.pet_teddy_play
    "grow" -> if (panda) R.drawable.pet_panda_grow else R.drawable.pet_teddy_grow
    "kiss" -> if (panda) R.drawable.pet_panda_kiss else R.drawable.pet_teddy_kiss
    "smile" -> if (panda) R.drawable.pet_panda_smile else R.drawable.pet_teddy_smile
    else -> if (panda) R.drawable.pet_panda_idle else R.drawable.pet_teddy_idle
  }
}
