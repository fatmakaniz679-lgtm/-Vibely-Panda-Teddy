package com.example.vibely.data

import kotlinx.coroutines.flow.Flow

class VibelyRepository(private val dao: VibelyDao) {
  val roomState: Flow<RoomStateEntity?> = dao.observeRoomState()
  val furniture: Flow<List<RoomFurnitureEntity>> = dao.observeFurniture()
  val memories: Flow<List<MemoryEntity>> = dao.observeMemories()
  val capsules: Flow<List<TimeCapsuleEntity>> = dao.observeCapsules()
  val chatMessages: Flow<List<ChatMessageEntity>> = dao.observeChatMessages()
  val reels: Flow<List<ReelEntity>> = dao.observeReels()
  val reelComments: Flow<List<ReelCommentEntity>> = dao.observeReelComments()
  val boards: Flow<List<BoardEntity>> = dao.observeBoards()
  val explorePins: Flow<List<ExplorePinEntity>> = dao.observeExplorePins()
  val tracks: Flow<List<PlaylistTrackEntity>> = dao.observeTracks()
  val cinemaTitles: Flow<List<CinemaTitleEntity>> = dao.observeCinemaTitles()
  val twoMinds: Flow<List<TwoMindsEntity>> = dao.observeTwoMinds()
  val profiles: Flow<List<UserProfileEntity>> = dao.observeProfiles()

  suspend fun seedIfEmpty() {
    if (dao.countRoomStates() > 0) return

    dao.upsertRoomState(RoomStateEntity())

    dao.upsertProfiles(
      listOf(
        UserProfileEntity(
          slot = "A",
          displayName = "Aria",
          handle = "aria.universe",
          bio = "Collecting sunset skies, cozy matcha mornings & polaroid moments.",
          avatarBadge = "Panda",
          favoriteSong = "Peach Cloud Lullaby",
          personalTheme = "Pastel Blush",
          diaryNote = "Rearranged our fairy lamp near the arched window today—feels so calm.",
          avatarTintHex = 0xFFFCDCE6,
        ),
        UserProfileEntity(
          slot = "B",
          displayName = "Zayn",
          handle = "zayn.universe",
          bio = "Late-night lo-fi beats, indie films, and rooftop stargazing.",
          avatarBadge = "Teddy",
          favoriteSong = "Midnight Rooftop Tape",
          personalTheme = "Soft Lavender",
          diaryNote = "Queued two classic public-domain films for our weekend Watch Together.",
          avatarTintHex = 0xFFEBE4FA,
        ),
      )
    )

    dao.upsertFurnitureAll(
      listOf(
        RoomFurnitureEntity(
          id = "sofa",
          name = "Cloud Velvet Sofa",
          category = "Furniture",
          iconKey = "sofa",
          xFraction = 0.44f,
          yFraction = 0.61f,
          isPlaced = true,
          accentColorHex = 0xFFFCDCE6,
        ),
        RoomFurnitureEntity(
          id = "lamp",
          name = "Warm Glow Lamp",
          category = "Lighting",
          iconKey = "lamp",
          xFraction = 0.16f,
          yFraction = 0.54f,
          isPlaced = true,
          accentColorHex = 0xFFFFE5D6,
        ),
        RoomFurnitureEntity(
          id = "plant",
          name = "Monstera Pot",
          category = "Plants",
          iconKey = "plant",
          xFraction = 0.77f,
          yFraction = 0.56f,
          isPlaced = true,
          accentColorHex = 0xFFDDF5EA,
        ),
        RoomFurnitureEntity(
          id = "frame",
          name = "Our Photo Frame",
          category = "Wall Decor",
          iconKey = "frame",
          xFraction = 0.16f,
          yFraction = 0.34f,
          isPlaced = true,
          accentColorHex = 0xFFEBE4FA,
        ),
        RoomFurnitureEntity(
          id = "bookshelf",
          name = "Mini Vinyl Shelf",
          category = "Decor",
          iconKey = "shelf",
          xFraction = 0.78f,
          yFraction = 0.76f,
          isPlaced = false,
          accentColorHex = 0xFFFFE5D6,
        ),
        RoomFurnitureEntity(
          id = "cushion",
          name = "Peach Floor Cushion",
          category = "Furniture",
          iconKey = "cushion",
          xFraction = 0.25f,
          yFraction = 0.77f,
          isPlaced = true,
          accentColorHex = 0xFFFFE5D6,
        ),
      )
    )

    dao.insertMemories(
      listOf(
        MemoryEntity(
          title = "First Rainy Rooftop Tea",
          note = "Watched the pastel twilight roll in with warm ginger tea and our lo-fi tape.",
          dateLabel = "Oct 14, 2026",
          moodTag = "Cozy",
          authorSlot = "A",
        ),
        MemoryEntity(
          title = "Decorated Our Virtual Loft",
          note = "Picked the cream woven rug, draped the fairy lights, and adopted Mochi the Panda.",
          dateLabel = "Nov 02, 2026",
          moodTag = "Joyful",
          authorSlot = "B",
        ),
      )
    )

    dao.insertCapsules(
      listOf(
        TimeCapsuleEntity(
          title = "Open on Our Anniversary",
          secretMessage = "Remember how peaceful this autumn evening felt—never stop making tiny rituals together.",
          unlockDateLabel = "Dec 31, 2026",
          isUnlocked = false,
          authorSlot = "A",
        ),
        TimeCapsuleEntity(
          title = "First Week Note",
          secretMessage = "You found the secret note! Treat yourself to iced strawberry matcha today.",
          unlockDateLabel = "Unlocked",
          isUnlocked = true,
          authorSlot = "B",
        ),
      )
    )

    dao.insertMessages(
      listOf(
        ChatMessageEntity(
          senderSlot = "B",
          text = "Added a new twilight track to Our Playlist—check out the Music Room!",
          attachmentType = "music",
          attachmentLabel = "Peach Cloud Lullaby",
          reactionEmoji = "✨",
        ),
        ChatMessageEntity(
          senderSlot = "A",
          text = "Love it! I just moved the warm lamp next to the sofa. Movie night in Vibely Cinema later?",
          attachmentType = "movie",
          attachmentLabel = "Charade (1963) • Watch Together",
          reactionEmoji = "💛",
        ),
      )
    )

    dao.insertReels(
      listOf(
        ReelEntity(
          authorSlot = "A",
          caption = "Golden hour tea steam by the window — slow Sunday ritual",
          audioTitle = "Peach Cloud Lullaby • Our Playlist",
          hashtags = "#cozyhome #goldenhour #vibely",
          filterTag = "Dreamy Pastel",
          likedByA = true,
          likedByB = true,
          isSaved = true,
          feedCategory = "For You",
          coverStyle = 0,
        ),
        ReelEntity(
          authorSlot = "B",
          caption = "Late night vinyl spin while sketching our dream room layout",
          audioTitle = "Midnight Rooftop Tape • Lo-Fi",
          hashtags = "#vinylnight #dreamroom #aesthetic",
          filterTag = "Vintage Film",
          likedByA = true,
          likedByB = false,
          isSaved = false,
          feedCategory = "Following",
          coverStyle = 1,
        ),
        ReelEntity(
          authorSlot = "A",
          caption = "Cloud watching with Panda filter on — draft saved for weekend",
          audioTitle = "Soft Lavender Rain • Ambient",
          hashtags = "#pandafilter #clouds #draft",
          filterTag = "Panda Ears",
          likedByA = false,
          likedByB = false,
          isSaved = false,
          isDraft = true,
          feedCategory = "For You",
          coverStyle = 2,
        ),
      )
    )

    dao.insertBoards(
      listOf(
        BoardEntity(name = "My Aesthetic", subtitle = "Soft blush & warm cream", accentHex = 0xFFFCDCE6),
        BoardEntity(name = "Dream Room", subtitle = "Cozy loft corners", accentHex = 0xFFFFE5D6),
        BoardEntity(name = "Favourite Songs", subtitle = "Vinyl & twilight mood", accentHex = 0xFFEBE4FA),
        BoardEntity(name = "Movie List", subtitle = "Watch Together picks", accentHex = 0xFFDDF5EA),
        BoardEntity(name = "Fashion Inspiration", subtitle = "Pastel knitwear", accentHex = 0xFFFCDCE6),
        BoardEntity(name = "Travel Dreams", subtitle = "Kyoto & coastal towns", accentHex = 0xFFFFE5D6),
      )
    )

    dao.insertExplorePins(
      listOf(
        ExplorePinEntity(title = "Sunlit Matcha Windowsill", category = "Aesthetic", colorTag = "Peach", heightRatio = 1.35f, savedBoardId = 1, artVariant = 0),
        ExplorePinEntity(title = "Arched Window Loft Corner", category = "Room Designs", colorTag = "Pink", heightRatio = 1.15f, savedBoardId = 2, artVariant = 1),
        ExplorePinEntity(title = "Crescent Moon Vinyl Art", category = "Music", colorTag = "Lavender", heightRatio = 1.0f, savedBoardId = 3, artVariant = 2),
        ExplorePinEntity(title = "Rooftop Lantern Cinema", category = "Movies", colorTag = "Midnight", heightRatio = 1.25f, savedBoardId = 4, artVariant = 3),
        ExplorePinEntity(title = "Cream Linen & Sakura", category = "Wallpapers", colorTag = "Pink", heightRatio = 1.4f, savedBoardId = 1, artVariant = 0),
        ExplorePinEntity(title = "Warm Terracotta Ceramic Mug", category = "Art", colorTag = "Peach", heightRatio = 1.05f, savedBoardId = null, artVariant = 4),
        ExplorePinEntity(title = "Kyoto Twilight Alleyway", category = "Travel", colorTag = "Lavender", heightRatio = 1.3f, savedBoardId = 6, artVariant = 5),
        ExplorePinEntity(title = "Soft Mohair Cardigan Look", category = "Fashion", colorTag = "Cream", heightRatio = 1.2f, savedBoardId = 5, artVariant = 6),
      )
    )

    dao.insertTracks(
      listOf(
        PlaylistTrackEntity(
          title = "Peach Cloud Lullaby",
          artist = "Sora & Mochi",
          album = "Warm Window Tapes",
          durationSec = 198,
          addedBySlot = "A",
          isFavorite = true,
          tintHex = 0xFFFCDCE6,
        ),
        PlaylistTrackEntity(
          title = "Midnight Rooftop Tape",
          artist = "Koi Cassette",
          album = "Lavender Frequencies",
          durationSec = 224,
          addedBySlot = "B",
          isFavorite = true,
          tintHex = 0xFFEBE4FA,
        ),
        PlaylistTrackEntity(
          title = "Rainy Porcelain Tea",
          artist = "Nori Acoustic",
          album = "Sunday Sketches",
          durationSec = 182,
          addedBySlot = "A",
          isFavorite = false,
          tintHex = 0xFFFFE5D6,
        ),
        PlaylistTrackEntity(
          title = "Starlight Polaroid",
          artist = "Velvet Moon",
          album = "Two Worlds EP",
          durationSec = 211,
          addedBySlot = "B",
          isFavorite = false,
          tintHex = 0xFFDDF5EA,
        ),
      )
    )

    dao.insertCinemaTitles(
      listOf(
        CinemaTitleEntity(
          id = "charade",
          title = "Charade",
          category = "Featured",
          genre = "Mystery • Romance",
          year = 1963,
          duration = "1h 53m",
          synopsis = "A sparkling Parisian romantic mystery full of twists, wit, and vintage cinema charm.",
          languages = "English",
          subtitles = "English, Hindi, French",
          sourceLabel = "Public Domain Classic • Discovery & Sync",
          inWatchlist = true,
          progressFraction = 0.34f,
          posterTone = 0,
        ),
        CinemaTitleEntity(
          id = "his_girl_friday",
          title = "His Girl Friday",
          category = "Movies",
          genre = "Classic Comedy",
          year = 1940,
          duration = "1h 32m",
          synopsis = "Rapid-fire banter and charm as a newspaper editor plots to win back his star reporter.",
          languages = "English",
          subtitles = "English",
          sourceLabel = "Public Domain Classic • Discovery",
          inWatchlist = true,
          progressFraction = 0f,
          posterTone = 1,
        ),
        CinemaTitleEntity(
          id = "moon_voyage",
          title = "A Trip to the Moon",
          category = "Movies",
          genre = "Fantasy • Short",
          year = 1902,
          duration = "14m",
          synopsis = "Georges Melies' whimsical hand-crafted silent voyage to the lunar surface.",
          languages = "Silent (Intertitles)",
          subtitles = "English",
          sourceLabel = "Public Domain Archive • Discovery",
          inWatchlist = false,
          progressFraction = 0.72f,
          posterTone = 2,
        ),
        CinemaTitleEntity(
          id = "pastel_nights",
          title = "Twilight Sketches",
          category = "Series",
          genre = "Cozy Anthology",
          year = 2025,
          duration = "6 Episodes",
          synopsis = "Curated guide to cozy indie short-film anthologies for quiet weekend watch parties.",
          languages = "English, Japanese",
          subtitles = "English, Hindi",
          sourceLabel = "Discovery Catalog • Connect Authorized Provider",
          inWatchlist = false,
          progressFraction = 0.15f,
          posterTone = 3,
        ),
      )
    )

    dao.insertTwoMinds(
      listOf(
        TwoMindsEntity(
          id = 1,
          prompt = "If we teleported to a cozy cottage tonight, what's the very first thing we'd do?",
          answerA = "Brew hot cocoa, put vinyl on, and watch the stars from the porch.",
          answerB = null,
        ),
        TwoMindsEntity(
          id = 2,
          prompt = "Which song instantly reminds you of our favorite day together?",
          answerA = "Peach Cloud Lullaby!",
          answerB = "Midnight Rooftop Tape while driving back after sunset.",
        ),
      )
    )
  }

  suspend fun upsertRoomState(state: RoomStateEntity) = dao.upsertRoomState(state)
  suspend fun updateFurniture(item: RoomFurnitureEntity) = dao.updateFurniture(item)
  suspend fun insertMemory(memory: MemoryEntity) = dao.insertMemory(memory)
  suspend fun deleteMemory(id: Int) = dao.deleteMemory(id)
  suspend fun insertCapsule(capsule: TimeCapsuleEntity) = dao.insertCapsule(capsule)
  suspend fun updateCapsule(capsule: TimeCapsuleEntity) = dao.updateCapsule(capsule)
  suspend fun insertMessage(message: ChatMessageEntity) = dao.insertMessage(message)
  suspend fun updateMessage(message: ChatMessageEntity) = dao.updateMessage(message)
  suspend fun deleteMessage(id: Int) = dao.deleteMessage(id)
  suspend fun insertReel(reel: ReelEntity) = dao.insertReel(reel)
  suspend fun updateReel(reel: ReelEntity) = dao.updateReel(reel)
  suspend fun insertReelComment(comment: ReelCommentEntity) = dao.insertReelComment(comment)
  suspend fun insertBoard(board: BoardEntity) = dao.insertBoard(board)
  suspend fun updateExplorePin(pin: ExplorePinEntity) = dao.updateExplorePin(pin)
  suspend fun insertTrack(track: PlaylistTrackEntity) = dao.insertTrack(track)
  suspend fun updateTrack(track: PlaylistTrackEntity) = dao.updateTrack(track)
  suspend fun updateCinemaTitle(title: CinemaTitleEntity) = dao.updateCinemaTitle(title)
  suspend fun updateTwoMind(item: TwoMindsEntity) = dao.updateTwoMind(item)
  suspend fun updateProfile(profile: UserProfileEntity) = dao.updateProfile(profile)
}
