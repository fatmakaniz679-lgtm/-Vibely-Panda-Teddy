package com.example.vibely.ui.music

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyLavender
import com.example.ui.theme.VibelyLavenderSoft
import com.example.ui.theme.VibelyPeachSoft
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.vibely.data.PlaylistTrackEntity
import com.example.vibely.data.UserProfileEntity
import com.example.vibely.viewmodel.MusicPlayerState

@Composable
fun MusicRoomScreen(
  tracks: List<PlaylistTrackEntity>,
  playerState: MusicPlayerState,
  profiles: List<UserProfileEntity>,
  onSelectTrack: (Int) -> Unit,
  onTogglePlayPause: () -> Unit,
  onNext: () -> Unit,
  onPrev: () -> Unit,
  onToggleShuffle: () -> Unit,
  onToggleRepeat: () -> Unit,
  onSeek: (Float) -> Unit,
  onToggleFavorite: (PlaylistTrackEntity) -> Unit,
  onAddTrack: (String, String) -> Unit,
  onBack: () -> Unit,
) {
  var searchQuery by remember { mutableStateOf("") }
  var showAddSongDialog by remember { mutableStateOf(false) }

  val currentTrack = tracks.getOrNull(playerState.currentTrackIndex.coerceIn(0, (tracks.size - 1).coerceAtLeast(0)))
  val filteredTracks =
    remember(tracks, searchQuery) {
      if (searchQuery.isBlank()) tracks
      else tracks.filter { it.title.contains(searchQuery, true) || it.artist.contains(searchQuery, true) }
    }

  Box(
    modifier =
      Modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(listOf(VibelyLavenderSoft, VibelyCream, VibelyPeachSoft.copy(alpha = 0.45f))))
  ) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Top Bar
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize().testTag("music_back_button")) {
              Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = stringResource(R.string.cd_back), tint = VibelyInk)
            }
            Column {
              Text("Music Room", style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
              Text("Our Playlist • Collaborative Listening", style = MaterialTheme.typography.labelSmall, color = VibelyLavender)
            }
          }
          Surface(
            onClick = { showAddSongDialog = true },
            shape = CircleShape,
            color = VibelyPink,
            modifier = Modifier.testTag("music_add_song_button"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Rounded.Add, contentDescription = "Add song", tint = Color.White, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text("Add Song", style = MaterialTheme.typography.labelMedium, color = Color.White)
            }
          }
        }
      }

      // Now Playing Hero Vinyl Card
      item {
        Surface(
          shape = RoundedCornerShape(30.dp),
          color = Color.White.copy(alpha = 0.92f),
          border = BorderStroke(1.dp, Color.White),
          shadowElevation = 8.dp,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Image(
              painter = painterResource(R.drawable.img_music_cover_1795279158690),
              contentDescription = currentTrack?.title ?: "Album cover",
              contentScale = ContentScale.Crop,
              modifier = Modifier.size(196.dp).shadow(10.dp, RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp)),
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = currentTrack?.title ?: "Select a Track",
                  style = MaterialTheme.typography.headlineSmall,
                  color = VibelyInk,
                )
                Text(
                  text = currentTrack?.let { "${it.artist} • ${it.album}" } ?: "Our Playlist",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              if (currentTrack != null) {
                IconButton(
                  onClick = { onToggleFavorite(currentTrack) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(
                    imageVector = if (currentTrack.isFavorite) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite song",
                    tint = VibelyPink,
                  )
                }
              }
            }

            Slider(
              value = playerState.progressFraction,
              onValueChange = onSeek,
              modifier = Modifier.fillMaxWidth(),
            )

            // Playback Controls
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceEvenly,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              IconButton(onClick = onToggleShuffle, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(
                  Icons.Rounded.Shuffle,
                  contentDescription = "Shuffle",
                  tint = if (playerState.isShuffle) VibelyPink else MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              IconButton(onClick = onPrev, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = stringResource(R.string.cd_prev_track), tint = VibelyInk, modifier = Modifier.size(30.dp))
              }
              Surface(
                onClick = onTogglePlayPause,
                shape = CircleShape,
                color = VibelyPink,
                shadowElevation = 6.dp,
                modifier = Modifier.size(62.dp).testTag("music_play_pause_button"),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = if (playerState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = stringResource(R.string.cd_play_pause),
                    tint = Color.White,
                    modifier = Modifier.size(34.dp),
                  )
                }
              }
              IconButton(onClick = onNext, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.Rounded.SkipNext, contentDescription = stringResource(R.string.cd_next_track), tint = VibelyInk, modifier = Modifier.size(30.dp))
              }
              IconButton(onClick = onToggleRepeat, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(
                  Icons.Rounded.Repeat,
                  contentDescription = "Repeat",
                  tint = if (playerState.isRepeat) VibelyPink else MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }
      }

      // Search & Our Playlist Queue
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Our Playlist", style = MaterialTheme.typography.titleLarge, color = VibelyInk)
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search songs or artists...") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = VibelyLavender) },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      itemsIndexed(filteredTracks, key = { _, t -> t.id }) { idx, track ->
        val isSelected = currentTrack?.id == track.id
        val adderName = profiles.firstOrNull { it.slot == track.addedBySlot }?.displayName ?: track.addedBySlot
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = if (isSelected) VibelyPinkSoft else Color.White.copy(alpha = 0.9f),
          border = BorderStroke(1.dp, if (isSelected) VibelyPink else Color.White),
          modifier = Modifier.fillMaxWidth().clickable { onSelectTrack(idx) }.testTag("music_track_${track.id}"),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Box(
              modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(track.tintHex)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = VibelyInk)
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(track.title, style = MaterialTheme.typography.titleMedium, color = VibelyInk, fontWeight = FontWeight.Bold)
              Text("${track.artist} • Added by $adderName", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { onToggleFavorite(track) }) {
              Icon(
                if (track.isFavorite) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = "Favorite",
                tint = if (track.isFavorite) VibelyPink else MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      item { Spacer(Modifier.height(16.dp)) }
    }
  }

  if (showAddSongDialog) {
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showAddSongDialog = false },
      title = { Text("Add to Our Playlist") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Song Title") }, singleLine = true)
          OutlinedTextField(value = artist, onValueChange = { artist = it }, label = { Text("Artist") }, singleLine = true)
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (title.isNotBlank()) {
              onAddTrack(title, artist)
              showAddSongDialog = false
            }
          }
        ) {
          Text("Add")
        }
      },
      dismissButton = { TextButton(onClick = { showAddSongDialog = false }) { Text("Cancel") } },
    )
  }
}
