package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibely Pastel Palette — Soft Pastel Pink, Warm Cream, White, Light Peach, Subtle Lavender
val VibelyPink = Color(0xFFE77B9B)
val VibelyPinkSoft = Color(0xFFFCDCE6)
val VibelyPinkBlush = Color(0xFFFFF0F5)
val VibelyOnPink = Color(0xFFFFFFFF)
val VibelyOnPinkSoft = Color(0xFF4A1828)

val VibelyPeach = Color(0xFFF29E7A)
val VibelyPeachSoft = Color(0xFFFFE5D6)
val VibelyOnPeachSoft = Color(0xFF4A2110)

val VibelyLavender = Color(0xFF9C89D8)
val VibelyLavenderSoft = Color(0xFFEBE4FA)
val VibelyOnLavenderSoft = Color(0xFF281C4C)

val VibelyCream = Color(0xFFFFF9F4)
val VibelySurfaceWhite = Color(0xFFFFFFFF)
val VibelyCreamVariant = Color(0xFFF6ECE6)
val VibelyInk = Color(0xFF2B2129)
val VibelyMuted = Color(0xFF726270)
val VibelyOutline = Color(0xFFE8D8D5)

// Cozy accents
val VibelyMint = Color(0xFF69B594)
val VibelyMintSoft = Color(0xFFDDF5EA)
val VibelyGold = Color(0xFFE5B55C)

// Dedicated Cinematic Dark Palette (Reels & Vibely Cinema)
val CinemaBg = Color(0xFF100E18)
val CinemaSurface = Color(0xFF1A1727)
val CinemaCard = Color(0xFF242036)
val CinemaText = Color(0xFFF9F4F7)
val CinemaMuted = Color(0xFFB6ABC2)
val CinemaAccentPink = Color(0xFFF59AB4)
val CinemaAccentPeach = Color(0xFFFFC4A3)
val CinemaAccentLavender = Color(0xFFC4B5F4)
