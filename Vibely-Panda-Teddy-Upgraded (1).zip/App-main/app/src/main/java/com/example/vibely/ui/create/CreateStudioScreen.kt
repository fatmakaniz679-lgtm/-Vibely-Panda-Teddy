package com.example.vibely.ui.create

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.CinemaAccentLavender
import com.example.ui.theme.CinemaAccentPeach
import com.example.ui.theme.CinemaAccentPink
import com.example.ui.theme.CinemaBg
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyPink

private data class StudioFilter(
  val name: String,
  val overlayTint: Color,
  val frameBadge: String?,
)

private val studioFilters =
  listOf(
    StudioFilter("Natural", Color.Transparent, null),
    StudioFilter("Panda Ears", Color(0xFFFFE4EC).copy(alpha = 0.14f), "🐼 Panda Frame"),
    StudioFilter("Teddy Glow", Color(0xFFFFD8B8).copy(alpha = 0.18f), "🧸 Teddy Frame"),
    StudioFilter("Dreamy", Color(0xFFE5D4FF).copy(alpha = 0.22f), "✨ Dreamy Haze"),
    StudioFilter("Vintage", Color(0xFFD9B99B).copy(alpha = 0.22f), "🎞 35mm Film"),
    StudioFilter("Warm Peach", Color(0xFFFFB899).copy(alpha = 0.20f), null),
    StudioFilter("Cool Lavender", Color(0xFFB7A6F6).copy(alpha = 0.20f), null),
    StudioFilter("Sparkle", Color(0xFFFFF2C2).copy(alpha = 0.16f), "✦ Stardust"),
  )

@Composable
fun CreateStudioScreen(
  onPublishReel: (caption: String, audio: String, hashtags: String, filter: String, mediaUri: String?, isDraft: Boolean) -> Unit,
  onSaveMemory: (title: String, note: String, mood: String, photoUri: String?) -> Unit,
  bottomContentPadding: PaddingValues,
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  var hasCameraPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED
    )
  }
  val permissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasCameraPermission = granted
    }

  var useFrontCamera by remember { mutableStateOf(true) }
  var flashOn by remember { mutableStateOf(false) }
  var timerSeconds by remember { mutableIntStateOf(0) }
  var selectedMode by remember { mutableStateOf("Snapshot") }
  var selectedFilter by remember { mutableStateOf(studioFilters.first()) }
  var importedUri by remember { mutableStateOf<String?>(null) }
  var isEditing by remember { mutableStateOf(false) }
  var feedbackBanner by remember { mutableStateOf<String?>(null) }

  // Editor state
  var brightness by remember { mutableFloatStateOf(0f) }
  var contrast by remember { mutableFloatStateOf(1f) }
  var saturation by remember { mutableFloatStateOf(1f) }
  var rotationDeg by remember { mutableFloatStateOf(0f) }
  var overlayText by remember { mutableStateOf("") }
  var selectedSticker by remember { mutableStateOf<String?>(null) }
  var caption by remember { mutableStateOf("") }
  var musicTrack by remember { mutableStateOf("Peach Cloud Lullaby") }

  val galleryLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        importedUri = uri.toString()
        isEditing = true
      }
    }

  if (isEditing) {
    // Photo & Video Studio Editor
    val colorMatrix =
      remember(brightness, contrast, saturation) {
        ColorMatrix().apply {
          setToSaturation(saturation)
          val t = brightness * 60f
          val c = contrast
          val scale =
            ColorMatrix(
              floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f,
              )
            )
          timesAssign(scale)
        }
      }

    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .background(VibelyCream)
          .statusBarsPadding()
          .verticalScroll(rememberScrollState())
          .padding(
            start = 18.dp,
            end = 18.dp,
            top = 12.dp,
            bottom = bottomContentPadding.calculateBottomPadding() + 24.dp,
          ),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Vibely Studio Editor", style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
        IconButton(onClick = { isEditing = false }) {
          Icon(Icons.Rounded.Close, contentDescription = "Close editor", tint = VibelyInk)
        }
      }

      // Live Edited Media Preview Card
      Box(
        modifier =
          Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(CinemaBg)
      ) {
        if (importedUri != null) {
          AsyncImage(
            model = importedUri,
            contentDescription = "Edited preview",
            contentScale = ContentScale.Crop,
            colorFilter = ColorFilter.colorMatrix(colorMatrix),
            modifier = Modifier.fillMaxSize().rotate(rotationDeg),
          )
        } else {
          Image(
            painter = painterResource(R.drawable.img_explore_aesthetic_1795279160167),
            contentDescription = "Captured studio frame",
            contentScale = ContentScale.Crop,
            colorFilter = ColorFilter.colorMatrix(colorMatrix),
            modifier = Modifier.fillMaxSize().rotate(rotationDeg),
          )
        }
        Box(modifier = Modifier.fillMaxSize().background(selectedFilter.overlayTint))

        selectedSticker?.let { sticker ->
          Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.align(Alignment.TopEnd).padding(14.dp),
          ) {
            Text(sticker, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
          }
        }
        if (overlayText.isNotBlank()) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.Black.copy(alpha = 0.52f),
            modifier = Modifier.align(Alignment.Center).padding(16.dp),
          ) {
            Text(overlayText, style = MaterialTheme.typography.titleLarge, color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
          }
        }
      }

      // Adjustments: Brightness, Contrast, Saturation, Rotate
      Surface(shape = RoundedCornerShape(20.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Tone & Transform", style = MaterialTheme.typography.titleMedium, color = VibelyInk)
            OutlinedButton(onClick = { rotationDeg = (rotationDeg + 90f) % 360f }) {
              Icon(Icons.Rounded.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(Modifier.width(4.dp))
              Text("Rotate")
            }
          }
          Text("Brightness", style = MaterialTheme.typography.labelMedium)
          Slider(value = brightness, onValueChange = { brightness = it }, valueRange = -1f..1f)
          Text("Contrast", style = MaterialTheme.typography.labelMedium)
          Slider(value = contrast, onValueChange = { contrast = it }, valueRange = 0.6f..1.5f)
          Text("Saturation", style = MaterialTheme.typography.labelMedium)
          Slider(value = saturation, onValueChange = { saturation = it }, valueRange = 0f..1.8f)
        }
      }

      // Stickers & Text Overlay
      Text("Cute Stickers", style = MaterialTheme.typography.titleMedium, color = VibelyInk)
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(listOf("🐼 Mochi", "🧸 Boba", "✨ Cozy", "🎀 Pastel", "🌙 Midnight", "☕ Matcha")) { sticker ->
          FilterChip(
            selected = selectedSticker == sticker,
            onClick = { selectedSticker = if (selectedSticker == sticker) null else sticker },
            label = { Text(sticker) },
          )
        }
      }

      OutlinedTextField(
        value = overlayText,
        onValueChange = { overlayText = it },
        label = { Text("Overlay Text") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )

      OutlinedTextField(
        value = caption,
        onValueChange = { caption = it },
        label = { Text("Caption for Reel or Memory") },
        modifier = Modifier.fillMaxWidth(),
      )

      OutlinedTextField(
        value = musicTrack,
        onValueChange = { musicTrack = it },
        label = { Text("Music Overlay Track") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )

      // Publish / Save Draft / Save Memory actions
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
          onClick = {
            onPublishReel(caption, musicTrack, "#vibely #draft", selectedFilter.name, importedUri, true)
            feedbackBanner = "Saved to Reel Drafts!"
            isEditing = false
          },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("editor_save_draft"),
        ) {
          Text("Save Draft")
        }
        Button(
          onClick = {
            onPublishReel(caption, musicTrack, "#vibely #duo", selectedFilter.name, importedUri, false)
            feedbackBanner = "Published to Private Reels!"
            isEditing = false
          },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("editor_publish_reel"),
        ) {
          Text("Post Reel")
        }
      }

      OutlinedButton(
        onClick = {
          onSaveMemory(
            caption.ifBlank { "Studio Snapshot" },
            overlayText.ifBlank { "Captured with ${selectedFilter.name} filter" },
            "Cozy",
            importedUri,
          )
          feedbackBanner = "Saved to Our Memories!"
          isEditing = false
        },
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("editor_save_memory"),
      ) {
        Text("Save to Our Memories")
      }
    }
    return
  }

  // Camera & Create Studio Viewfinder
  Box(modifier = Modifier.fillMaxSize().background(CinemaBg)) {
    if (hasCameraPermission) {
      CameraXPreviewSurface(
        useFrontCamera = useFrontCamera,
        lifecycleOwner = lifecycleOwner,
        modifier = Modifier.fillMaxSize(),
      )
    } else {
      // Studio Fallback Canvas with clean Camera Permission CTA
      Box(modifier = Modifier.fillMaxSize()) {
        Image(
          painter = painterResource(R.drawable.img_virtual_room_bg_1795279159875),
          contentDescription = "Studio preview",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        Box(modifier = Modifier.fillMaxSize().background(CinemaBg.copy(alpha = 0.56f)))
        Column(
          modifier = Modifier.align(Alignment.Center).padding(28.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Icon(Icons.Rounded.CameraAlt, contentDescription = null, tint = CinemaAccentPink, modifier = Modifier.size(48.dp))
          Text("Vibely Camera Studio", style = MaterialTheme.typography.headlineSmall, color = Color.White)
          Text(
            "Enable CameraX for live viewfinder preview, or import a photo from your gallery to open the creative editor.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.8f),
          )
          Button(
            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
            shape = CircleShape,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("enable_camera_button"),
          ) {
            Text("Enable Live Camera")
          }
        }
      }
    }

    // Active Live Filter Tint & Creative Frame Overlay
    Box(modifier = Modifier.fillMaxSize().background(selectedFilter.overlayTint))
    selectedFilter.frameBadge?.let { badge ->
      Surface(
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.85f),
        modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 66.dp),
      ) {
        Text(badge, style = MaterialTheme.typography.labelLarge, color = VibelyInk, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
      }
    }

    feedbackBanner?.let { msg ->
      Surface(
        shape = CircleShape,
        color = VibelyPink,
        onClick = { feedbackBanner = null },
        modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 108.dp),
      ) {
        Text(msg, style = MaterialTheme.typography.labelLarge, color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
      }
    }

    // Top Camera Controls (Flash, Timer, Flip)
    Row(
      modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.45f)) {
        Text(
          text = "Create • $selectedMode",
          style = MaterialTheme.typography.labelLarge,
          color = Color.White,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StudioCircleIcon(
          icon = if (flashOn) Icons.Rounded.FlashOn else Icons.Rounded.FlashOff,
          desc = stringResource(R.string.cd_flash),
          active = flashOn,
          onClick = { flashOn = !flashOn },
        )
        StudioCircleIcon(
          icon = Icons.Rounded.Timer,
          desc = "Timer ${timerSeconds}s",
          active = timerSeconds > 0,
          onClick = { timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 } },
        )
        StudioCircleIcon(
          icon = Icons.Rounded.Cameraswitch,
          desc = stringResource(R.string.cd_flip_camera),
          active = false,
          onClick = { useFrontCamera = !useFrontCamera },
        )
      }
    }

    // Bottom Studio Controls: Filter Carousel, Shutter, Gallery, Mode Selector
    Column(
      modifier =
        Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .padding(bottom = bottomContentPadding.calculateBottomPadding() + 18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Live Filter Selector
      LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(studioFilters) { filter ->
          val active = selectedFilter.name == filter.name
          Surface(
            onClick = { selectedFilter = filter },
            shape = CircleShape,
            color = if (active) CinemaAccentPink else Color.Black.copy(alpha = 0.5f),
            border = BorderStroke(1.dp, if (active) Color.White else Color.White.copy(alpha = 0.25f)),
            modifier = Modifier.testTag("filter_${filter.name}"),
          ) {
            Text(
              text = filter.name,
              style = MaterialTheme.typography.labelMedium,
              color = if (active) CinemaBg else Color.White,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            )
          }
        }
      }

      // Gallery Import + Shutter + Studio Editor shortcut
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          onClick = {
            galleryLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          },
          shape = RoundedCornerShape(16.dp),
          color = Color.White.copy(alpha = 0.2f),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
          modifier = Modifier.size(50.dp).testTag("camera_gallery_button"),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PhotoLibrary, contentDescription = stringResource(R.string.cd_gallery), tint = Color.White)
          }
        }

        // Shutter Button
        Box(
          modifier =
            Modifier
              .size(76.dp)
              .clip(CircleShape)
              .border(4.dp, Color.White, CircleShape)
              .padding(6.dp)
              .clip(CircleShape)
              .background(if (selectedMode == "Reel") CinemaAccentPink else Color.White)
              .clickable {
                importedUri = null
                isEditing = true
              }
              .testTag("camera_shutter_button"),
        )

        Surface(
          onClick = { isEditing = true },
          shape = RoundedCornerShape(16.dp),
          color = Color.White.copy(alpha = 0.2f),
          border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
          modifier = Modifier.size(50.dp).testTag("camera_open_editor_button"),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.AutoAwesome, contentDescription = "Open Editor", tint = CinemaAccentPeach)
          }
        }
      }

      // Create Menu Modes
      LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        items(listOf("Snapshot", "Reel", "Story", "Collage", "Upload")) { mode ->
          val active = selectedMode == mode
          Text(
            text = mode,
            style = MaterialTheme.typography.labelLarge,
            color = if (active) CinemaAccentPeach else Color.White.copy(alpha = 0.65f),
            modifier =
              Modifier
                .clickable {
                  selectedMode = mode
                  if (mode == "Upload") {
                    galleryLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                  }
                }
                .padding(horizontal = 6.dp, vertical = 4.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun StudioCircleIcon(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  desc: String,
  active: Boolean,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    shape = CircleShape,
    color = if (active) CinemaAccentLavender else Color.Black.copy(alpha = 0.45f),
    modifier = Modifier.size(42.dp),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Icon(icon, contentDescription = desc, tint = if (active) CinemaBg else Color.White, modifier = Modifier.size(20.dp))
    }
  }
}

@Composable
private fun CameraXPreviewSurface(
  useFrontCamera: Boolean,
  lifecycleOwner: androidx.lifecycle.LifecycleOwner,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val previewView = remember { PreviewView(context) }

  DisposableEffect(useFrontCamera, lifecycleOwner) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
    val executor = ContextCompat.getMainExecutor(context)
    val listener = Runnable {
      runCatching {
        val provider = cameraProviderFuture.get()
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        val selector =
          if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        provider.unbindAll()
        provider.bindToLifecycle(lifecycleOwner, selector, preview)
      }
    }
    cameraProviderFuture.addListener(listener, executor)
    onDispose {
      runCatching { cameraProviderFuture.get().unbindAll() }
    }
  }

  AndroidView(factory = { previewView }, modifier = modifier)
}
