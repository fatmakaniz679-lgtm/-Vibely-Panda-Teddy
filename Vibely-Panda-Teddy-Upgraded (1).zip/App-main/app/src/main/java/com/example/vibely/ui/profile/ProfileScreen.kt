package com.example.vibely.ui.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.VibelyCream
import com.example.ui.theme.VibelyInk
import com.example.ui.theme.VibelyLavender
import com.example.ui.theme.VibelyLavenderSoft
import com.example.ui.theme.VibelyMint
import com.example.ui.theme.VibelyMintSoft
import com.example.ui.theme.VibelyPeachSoft
import com.example.ui.theme.VibelyPink
import com.example.ui.theme.VibelyPinkSoft
import com.example.vibely.data.RoomStateEntity
import com.example.vibely.data.UserProfileEntity

@Composable
fun ProfileScreen(
  roomState: RoomStateEntity,
  profiles: List<UserProfileEntity>,
  savedPinsCount: Int,
  favoriteTracksCount: Int,
  savedReelsCount: Int,
  onSwitchAccount: () -> Unit,
  onTogglePrivacy: () -> Unit,
  onSaveProfile: (name: String, bio: String, song: String, diary: String) -> Unit,
  bottomContentPadding: PaddingValues,
) {
  val activeProfile = profiles.firstOrNull { it.slot == roomState.activeUserSlot } ?: profiles.firstOrNull()
  var isEditing by remember(activeProfile?.slot) { mutableStateOf(false) }

  var draftName by remember(activeProfile) { mutableStateOf(activeProfile?.displayName ?: "") }
  var draftBio by remember(activeProfile) { mutableStateOf(activeProfile?.bio ?: "") }
  var draftSong by remember(activeProfile) { mutableStateOf(activeProfile?.favoriteSong ?: "") }
  var draftDiary by remember(activeProfile) { mutableStateOf(activeProfile?.diaryNote ?: "") }

  Column(
    modifier =
      Modifier
        .fillMaxSize()
        .background(VibelyCream)
        .statusBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(
          start = 18.dp,
          end = 18.dp,
          top = 12.dp,
          bottom = bottomContentPadding.calculateBottomPadding() + 26.dp,
        ),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Header + Two-Account Switcher (No public follower counts!)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text("Profile & Personal Corner", style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
        Text("Private Universe • 2 Authorized Accounts", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
      OutlinedButton(
        onClick = onSwitchAccount,
        shape = CircleShape,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("profile_switch_account"),
      ) {
        Icon(Icons.Rounded.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text("Switch")
      }
    }

    // Active User Profile Hero Card
    if (activeProfile != null) {
      Surface(
        shape = RoundedCornerShape(26.dp),
        color = Color.White,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        shadowElevation = 3.dp,
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
              modifier =
                Modifier
                  .size(68.dp)
                  .background(Color(activeProfile.avatarTintHex), CircleShape)
                  .border(2.5.dp, VibelyPink, CircleShape),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                activeProfile.displayName.firstOrNull()?.toString() ?: activeProfile.slot,
                style = MaterialTheme.typography.headlineMedium,
                color = VibelyInk,
              )
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(activeProfile.displayName, style = MaterialTheme.typography.headlineSmall, color = VibelyInk)
              Text("@${activeProfile.handle} • ${activeProfile.avatarBadge} Avatar", style = MaterialTheme.typography.bodyMedium, color = VibelyPink)
              Text("Theme: ${activeProfile.personalTheme}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }

          Text(activeProfile.bio, style = MaterialTheme.typography.bodyLarge, color = VibelyInk)

          Surface(shape = RoundedCornerShape(14.dp), color = VibelyLavenderSoft) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = VibelyLavender, modifier = Modifier.size(18.dp))
              Text("Favourite Song: ${activeProfile.favoriteSong}", style = MaterialTheme.typography.labelLarge, color = VibelyInk)
            }
          }

          // Personal Collection Stats (Strictly Personal — No Follower Metrics)
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PersonalMetricTile("Saved Pins", savedPinsCount.toString(), VibelyPinkSoft, Modifier.weight(1f))
            PersonalMetricTile("Fav Songs", favoriteTracksCount.toString(), VibelyPeachSoft, Modifier.weight(1f))
            PersonalMetricTile("Saved Reels", savedReelsCount.toString(), VibelyMintSoft, Modifier.weight(1f))
          }

          OutlinedButton(
            onClick = { isEditing = !isEditing },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("profile_edit_button"),
          ) {
            Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(if (isEditing) "Cancel Editing" else "Customize Profile & Diary")
          }
        }
      }

      // Personal Corner (Private Diary & Notes)
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, VibelyPeachSoft),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Rounded.Lock, contentDescription = null, tint = VibelyPink, modifier = Modifier.size(20.dp))
            Text("${activeProfile.displayName}'s Personal Corner", style = MaterialTheme.typography.titleLarge, color = VibelyInk)
          }

          if (isEditing) {
            OutlinedTextField(value = draftName, onValueChange = { draftName = it }, label = { Text("Display Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draftBio, onValueChange = { draftBio = it }, label = { Text("Bio") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draftSong, onValueChange = { draftSong = it }, label = { Text("Favourite Song") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = draftDiary, onValueChange = { draftDiary = it }, label = { Text("Private Diary Note") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            Button(
              onClick = {
                onSaveProfile(draftName, draftBio, draftSong, draftDiary)
                isEditing = false
              },
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("profile_save_button"),
            ) {
              Text("Save Personal Changes")
            }
          } else {
            Text("Private Diary Entry", style = MaterialTheme.typography.labelMedium, color = VibelyPink)
            Text(activeProfile.diaryNote, style = MaterialTheme.typography.bodyLarge, color = VibelyInk)
          }
        }
      }
    }

    // Two-Account Security & Privacy Controls
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      border = BorderStroke(1.dp, VibelyMintSoft),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = VibelyMint, modifier = Modifier.size(22.dp))
          Text("Two-Account Access Control", style = MaterialTheme.typography.titleLarge, color = VibelyInk)
        }
        Text(
          "Authorized Slots: 2 / 2 Filled (${profiles.joinToString(" & ") { it.displayName }})\nInvitation Code: ${roomState.inviteCode}",
          style = MaterialTheme.typography.bodyMedium,
          color = VibelyInk,
        )
        Text(
          "Storage Mode: Local On-Device Room Database (cloud sync can be enabled anytime via Firebase or Supabase).",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Share Online Presence", style = MaterialTheme.typography.titleMedium, color = VibelyInk)
          Switch(checked = roomState.showOnlineStatus, onCheckedChange = { onTogglePrivacy() })
        }
      }
    }
  }
}

@Composable
private fun PersonalMetricTile(
  label: String,
  value: String,
  tint: Color,
  modifier: Modifier = Modifier,
) {
  Surface(shape = RoundedCornerShape(16.dp), color = tint, modifier = modifier) {
    Column(modifier = Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = VibelyInk)
      Text(label, style = MaterialTheme.typography.labelSmall, color = VibelyInk)
    }
  }
}
